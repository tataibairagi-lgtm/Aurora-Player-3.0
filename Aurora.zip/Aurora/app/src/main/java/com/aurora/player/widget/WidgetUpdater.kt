package com.aurora.player.widget

import android.Manifest
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.view.View
import android.widget.RemoteViews
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import com.aurora.player.MainActivity
import com.aurora.player.R
import com.aurora.player.controller
import com.aurora.player.data.MediaScanner
import com.aurora.player.data.Track
import com.aurora.player.player.PlayerController
import com.aurora.player.ui.ArtLoader
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

const val ACTION_PLAY_PAUSE = "aurora.widget.PLAY_PAUSE"
const val ACTION_NEXT = "aurora.widget.NEXT"
const val ACTION_PREV = "aurora.widget.PREV"
const val ACTION_SHUFFLE = "aurora.widget.SHUFFLE"
const val ACTION_REPEAT = "aurora.widget.REPEAT"
const val ACTION_FAVOURITE = "aurora.widget.FAVOURITE"
const val ACTION_JUMP = "aurora.widget.JUMP"
const val EXTRA_INDEX = "index"

private class Spec(
    val provider: Class<*>,
    val layout: Int,
    val artPx: Int,
    val fav: Boolean = false,
    val progress: Boolean = false,
    val modes: Boolean = false,
    val queue: Boolean = false,
    val list: Boolean = false,
)

private val specs = listOf(
    Spec(MiniWidget::class.java, R.layout.widget_mini, 160),
    Spec(StandardWidget::class.java, R.layout.widget_standard, 280, fav = true, progress = true),
    Spec(SquareWidget::class.java, R.layout.widget_square, 360),
    Spec(LargeWidget::class.java, R.layout.widget_large, 420, fav = true, progress = true, modes = true, queue = true),
    Spec(QueueWidget::class.java, R.layout.widget_queue, 240, fav = true, list = true),
)

/** Redraws every Aurora widget on the home screen from the current player state. */
object WidgetUpdater {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var generation = 0

    fun update(ctx: Context) {
        val app = ctx.applicationContext
        val mgr = AppWidgetManager.getInstance(app)
        val placed = specs.map { it to mgr.getAppWidgetIds(ComponentName(app, it.provider)) }
            .filter { it.second.isNotEmpty() }
        if (placed.isEmpty()) return

        val mine = ++generation
        scope.launch {
            val c = app.controller
            // Cold start (e.g. widget tapped while the app is closed): load the library so the last song shows.
            if (c.library.isEmpty() && hasAudioPermission(app)) {
                val list = withContext(Dispatchers.IO) { runCatching { MediaScanner.scan(app) }.getOrDefault(emptyList()) }
                if (list.isNotEmpty()) c.attachLibrary(list)
            }
            val t = c.current
            val art = t?.let { ArtLoader.load(app, it) }
            if (mine != generation) return@launch // a newer update is already on its way
            for ((spec, ids) in placed) {
                val views = build(app, spec, c, t, art)
                mgr.updateAppWidget(ids, views)
                if (spec.list) mgr.notifyAppWidgetViewDataChanged(ids, R.id.w_list)
            }
        }
    }

    private fun hasAudioPermission(ctx: Context): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(ctx, p) == PackageManager.PERMISSION_GRANTED
    }

    private fun scaled(b: Bitmap, px: Int): Bitmap {
        if (b.width <= px && b.height <= px) return b
        val f = px / maxOf(b.width, b.height).toFloat()
        return Bitmap.createScaledBitmap(b, (b.width * f).toInt().coerceAtLeast(1), (b.height * f).toInt().coerceAtLeast(1), true)
    }

    private fun action(ctx: Context, act: String): PendingIntent = PendingIntent.getBroadcast(
        ctx, act.hashCode(), Intent(ctx, WidgetActionReceiver::class.java).setAction(act),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
    )

    private fun build(ctx: Context, s: Spec, c: PlayerController, t: Track?, art: Bitmap?): RemoteViews {
        val v = RemoteViews(ctx.packageName, s.layout)
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        v.setOnClickPendingIntent(R.id.w_root, open)
        v.setOnClickPendingIntent(R.id.w_art, open)

        v.setTextViewText(R.id.w_title, t?.title ?: "Aurora")
        v.setTextViewText(R.id.w_artist, t?.artist ?: "Tap to open your music")
        if (art != null) v.setImageViewBitmap(R.id.w_art, scaled(art, s.artPx))
        else v.setImageViewResource(R.id.w_art, R.drawable.ic_logo)

        v.setImageViewResource(R.id.w_play, if (c.isPlaying) R.drawable.ic_w_pause else R.drawable.ic_w_play)
        v.setOnClickPendingIntent(R.id.w_play, action(ctx, ACTION_PLAY_PAUSE))
        v.setOnClickPendingIntent(R.id.w_next, action(ctx, ACTION_NEXT))
        v.setOnClickPendingIntent(R.id.w_prev, action(ctx, ACTION_PREV))

        if (s.fav) {
            val fav = t != null && c.store.isFavourite(t.id)
            v.setImageViewResource(R.id.w_fav, if (fav) R.drawable.ic_w_fav else R.drawable.ic_w_fav_off)
            v.setOnClickPendingIntent(R.id.w_fav, action(ctx, ACTION_FAVOURITE))
        }
        if (s.progress) {
            val p = if (c.durationMs > 0) (c.positionMs * 1000 / c.durationMs).toInt().coerceIn(0, 1000) else 0
            v.setProgressBar(R.id.w_progress, 1000, p, false)
        }
        if (s.modes) {
            v.setImageViewResource(
                R.id.w_repeat,
                if (c.repeatMode == Player.REPEAT_MODE_ONE) R.drawable.ic_w_repeat_one else R.drawable.ic_w_repeat,
            )
            // dim the buttons that are switched off
            v.setInt(R.id.w_shuffle, "setImageAlpha", if (c.shuffle) 255 else 110)
            v.setInt(R.id.w_repeat, "setImageAlpha", if (c.repeatMode != Player.REPEAT_MODE_OFF) 255 else 110)
            v.setOnClickPendingIntent(R.id.w_shuffle, action(ctx, ACTION_SHUFFLE))
            v.setOnClickPendingIntent(R.id.w_repeat, action(ctx, ACTION_REPEAT))
        }
        if (s.queue) {
            val ids = intArrayOf(R.id.w_q1, R.id.w_q2, R.id.w_q3)
            ids.forEachIndexed { i, id ->
                val n = c.queue.getOrNull(c.currentIndex + 1 + i)
                v.setTextViewText(id, n?.let { "${i + 1}. ${it.title} · ${it.artist}" } ?: "")
                v.setViewVisibility(id, if (n != null || i == 0) View.VISIBLE else View.GONE)
            }
        }
        if (s.list) decorateQueue(ctx, v, c, t)
        return v
    }

    private var lastScrolledTo: Long = -1

    /** Queue widget: wallpaper-based colours, the scrolling list and the header shortcuts. */
    private fun decorateQueue(ctx: Context, v: RemoteViews, c: PlayerController, t: Track?) {
        val th = WidgetTheme.resolve(ctx, c.store.data.queueTheme)

        // translucent rounded panels: colour filter for the colour, image alpha for the see-through part
        v.setInt(R.id.w_bg_header, "setColorFilter", th.header)
        v.setInt(R.id.w_bg_header, "setImageAlpha", th.headerAlpha)
        v.setInt(R.id.w_bg_panel, "setColorFilter", th.panel)
        v.setInt(R.id.w_bg_panel, "setImageAlpha", th.panelAlpha)
        v.setInt(R.id.w_fab_bg, "setColorFilter", th.accent)

        v.setTextColor(R.id.w_title, th.accent)
        v.setTextColor(R.id.w_artist, th.sub)
        v.setTextColor(R.id.w_q_title, th.text)
        v.setTextColor(R.id.w_empty, th.sub)
        for (id in intArrayOf(R.id.w_fav, R.id.w_prev, R.id.w_play, R.id.w_next, R.id.w_open_queue)) {
            v.setInt(id, "setColorFilter", th.accent)
        }

        val size = c.queue.size
        v.setTextViewText(R.id.w_q_title, if (size == 0) "Current Queue" else "Current Queue (${c.currentIndex + 1}/$size)")

        val openQueue = PendingIntent.getActivity(
            ctx, 1,
            Intent(ctx, MainActivity::class.java).putExtra("route", "queue")
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        v.setOnClickPendingIntent(R.id.w_open_queue, openQueue)
        v.setOnClickPendingIntent(R.id.w_fab, openQueue)

        v.setRemoteAdapter(R.id.w_list, Intent(ctx, QueueWidgetService::class.java))
        v.setEmptyView(R.id.w_list, R.id.w_empty)
        // tapping a row plays it (the row supplies its own index; the template must be mutable for that)
        val template = PendingIntent.getBroadcast(
            ctx, 77, Intent(ctx, WidgetActionReceiver::class.java).setAction(ACTION_JUMP),
            PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= 31) PendingIntent.FLAG_MUTABLE else 0),
        )
        v.setPendingIntentTemplate(R.id.w_list, template)

        // keep the playing song in view, but only when the song changes so manual scrolling isn't undone
        val id = t?.id ?: -1
        if (id != lastScrolledTo && c.currentIndex >= 0) {
            lastScrolledTo = id
            v.setScrollPosition(R.id.w_list, (c.currentIndex - 1).coerceAtLeast(0))
        }
    }
}
