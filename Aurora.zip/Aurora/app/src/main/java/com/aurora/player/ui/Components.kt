package com.aurora.player.ui

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController

/** Things only the Activity can do (permission flows, system pickers). */
class Actions(
    val editTags: (Track, String, String, String) -> Unit,
    val importLyrics: () -> Unit,
    val importPlaylist: () -> Unit,
    val exportPlaylist: (String, List<Track>) -> Unit,
    val toggleOverlay: (Boolean) -> Unit,
    val rescan: () -> Unit,
    val chooseBackupFolder: () -> Unit,
    val backupNow: () -> Unit,
    val openRestore: () -> Unit,
    val browseBackup: () -> Unit,
    val loadBackup: (android.net.Uri, String) -> Unit,
    val applyRestore: (com.aurora.player.backup.LoadedBackup, com.aurora.player.backup.RestoreOptions) -> Unit,
    val ensureOverlayPermission: () -> Boolean,
)

val LocalActions = compositionLocalOf<Actions> { error("Actions not provided") }

@Composable
fun TrackRow(
    t: Track,
    c: PlayerController,
    modifier: Modifier = Modifier,
    extraMenu: List<Pair<String, () -> Unit>> = emptyList(),
    playCount: Int? = null,
    onClick: () -> Unit,
) {
    val isCurrent = c.current?.id == t.id
    val bg by animateColorAsState(
        if (isCurrent) MaterialTheme.colorScheme.primary.copy(alpha = 0.12f) else MaterialTheme.colorScheme.background.copy(alpha = 0f),
        tween(300), label = "rowBg",
    )
    var menu by remember { mutableStateOf(false) }
    var addDialog by remember { mutableStateOf(false) }
    var tagDialog by remember { mutableStateOf(false) }
    val actions = LocalActions.current

    Row(
        modifier
            .fillMaxWidth()
            .padding(horizontal = 8.dp, vertical = 2.dp)
            .background(bg, RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(contentAlignment = Alignment.Center) {
            AlbumArt(t, Modifier.size(48.dp), RoundedCornerShape(12.dp), 22.dp)
            if (isCurrent) {
                Box(
                    Modifier.size(48.dp).background(androidx.compose.ui.graphics.Color.Black.copy(alpha = 0.35f), RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center,
                ) {
                    EqualizerBars(c.isPlaying, androidx.compose.ui.graphics.Color.White, Modifier.size(20.dp))
                }
            }
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(
                t.title, maxLines = 1, overflow = TextOverflow.Ellipsis,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                color = if (isCurrent) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface,
            )
            Text(
                "${t.artist} · ${t.album}", maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
        if (c.store.isFavourite(t.id)) {
            Icon(Icons.Rounded.Favorite, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
        }
        if (playCount != null) {
            // how many times it was played, as a coloured badge with the duration under it (like Musicolet)
            Column(Modifier.padding(start = 6.dp), horizontalAlignment = Alignment.End) {
                Box(
                    Modifier.defaultMinSize(minWidth = 26.dp, minHeight = 26.dp)
                        .background(MaterialTheme.colorScheme.primary, RoundedCornerShape(5.dp))
                        .padding(horizontal = 6.dp),
                    contentAlignment = Alignment.Center,
                ) {
                    Text(playCount.toString(), color = MaterialTheme.colorScheme.onPrimary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                }
                Text(
                    formatTime(t.durationMs), style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(top = 2.dp),
                )
            }
        } else {
            Text(
                formatTime(t.durationMs), style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 6.dp),
            )
        }
        Box {
            Box(Modifier.size(36.dp).bounceClick { menu = true }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.MoreVert, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            DropdownMenu(menu, { menu = false }) {
                DropdownMenuItem(text = { Text("Play next") }, onClick = { menu = false; c.playNext(t) })
                DropdownMenuItem(text = { Text("Add to queue") }, onClick = { menu = false; c.addToQueue(t) })
                DropdownMenuItem(text = { Text("Add to playlist") }, onClick = { menu = false; addDialog = true })
                DropdownMenuItem(
                    text = { Text(if (c.store.isFavourite(t.id)) "Remove from favourites" else "Add to favourites") },
                    onClick = { menu = false; c.store.toggleFavourite(t.id) },
                )
                DropdownMenuItem(text = { Text("Edit tags") }, onClick = { menu = false; tagDialog = true })
                extraMenu.forEach { (label, act) ->
                    DropdownMenuItem(text = { Text(label) }, onClick = { menu = false; act() })
                }
            }
        }
    }
    if (addDialog) AddToPlaylistDialog(c, listOf(t.id)) { addDialog = false }
    if (tagDialog) TagEditorDialog(t, { tagDialog = false }) { title, artist, album ->
        tagDialog = false
        actions.editTags(t, title, artist, album)
    }
}

@Composable
fun AddToPlaylistDialog(c: PlayerController, ids: List<Long>, onDismiss: () -> Unit) {
    var newName by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add to playlist") },
        text = {
            Column {
                LazyColumn(Modifier.heightIn(max = 240.dp)) {
                    items(c.store.data.playlists, key = { it.id }) { p ->
                        Text(
                            "${p.name}  (${p.trackIds.size})",
                            Modifier.fillMaxWidth().clickable { c.store.addToPlaylist(p.id, ids); onDismiss() }.padding(vertical = 12.dp),
                        )
                    }
                }
                OutlinedTextField(
                    newName, { newName = it }, label = { Text("New playlist") }, singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = { if (newName.isNotBlank()) { c.store.createPlaylist(newName, ids); onDismiss() } },
                enabled = newName.isNotBlank(),
            ) { Text("Create & add") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun TagEditorDialog(t: Track, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var title by remember { mutableStateOf(t.title) }
    var artist by remember { mutableStateOf(t.artist) }
    var album by remember { mutableStateOf(t.album) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit tags") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(title, { title = it }, label = { Text("Title") }, singleLine = true)
                OutlinedTextField(artist, { artist = it }, label = { Text("Artist") }, singleLine = true)
                OutlinedTextField(album, { album = it }, label = { Text("Album") }, singleLine = true)
                Text(
                    "Updates how the song appears in the Android media library. The audio file itself is not rewritten.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = { TextButton({ onSave(title, artist, album) }) { Text("Save") } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

@Composable
fun NameDialog(title: String, initial: String = "", confirm: String = "OK", onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var v by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(v, { v = it }, singleLine = true, modifier = Modifier.fillMaxWidth()) },
        confirmButton = { TextButton({ if (v.isNotBlank()) onOk(v) }, enabled = v.isNotBlank()) { Text(confirm) } },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}
