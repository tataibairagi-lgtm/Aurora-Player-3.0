package com.aurora.player.data

/** Reads and writes .m3u / .m3u8 / .pls playlist files (the format Musicolet exports playlists in). */
object PlaylistIo {
    private val plsFile = Regex("""^File\d+=(.*)$""", RegexOption.IGNORE_CASE)
    private val plsMeta = Regex("""^(Title|Length)\d+=|^(NumberOfEntries|Version)=|^\[playlist]""", RegexOption.IGNORE_CASE)

    /** The file paths / names listed in the playlist, in order. */
    fun parse(text: String): List<String> {
        val out = ArrayList<String>()
        for (raw in text.lines()) {
            val l = raw.trim().removePrefix("﻿")
            if (l.isEmpty() || l.startsWith("#")) continue
            val pls = plsFile.find(l)
            if (pls != null) {
                out += pls.groupValues[1].trim()
                continue
            }
            if (plsMeta.containsMatchIn(l)) continue
            out += l
        }
        return out
    }

    /** Maps playlist entries onto songs in the library: exact path first, then by file name. */
    fun match(entries: List<String>, library: List<Track>): List<Long> {
        val byPath = library.filter { it.path.isNotEmpty() }.associateBy { it.path }
        val byName = library.groupBy { it.path.substringAfterLast('/').lowercase() }
        val ids = ArrayList<Long>()
        for (e in entries) {
            val norm = e.replace('\\', '/').removePrefix("file://")
            val hit = byPath[norm]
                ?: byName[norm.substringAfterLast('/').lowercase()]?.let { cands ->
                    // several songs with the same file name: prefer the one whose folder also matches
                    cands.maxByOrNull { sharedSuffix(it.path, norm) }
                }
            if (hit != null && hit.id !in ids) ids += hit.id
        }
        return ids
    }

    private fun sharedSuffix(a: String, b: String): Int {
        var n = 0
        while (n < a.length && n < b.length && a[a.length - 1 - n] == b[b.length - 1 - n]) n++
        return n
    }

    fun toM3u(tracks: List<Track>): String = buildString {
        append("#EXTM3U\n")
        for (t in tracks) {
            append("#EXTINF:").append(t.durationMs / 1000).append(',').append(t.artist).append(" - ").append(t.title).append('\n')
            append(t.path).append('\n')
        }
    }
}
