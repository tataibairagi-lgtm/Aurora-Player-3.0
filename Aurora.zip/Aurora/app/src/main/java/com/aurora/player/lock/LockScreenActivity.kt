package com.aurora.player.lock

import android.app.KeyguardManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.text.format.DateFormat
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import com.aurora.player.controller
import com.aurora.player.data.formatTime
import com.aurora.player.data.indexAt
import com.aurora.player.player.PlayerController
import com.aurora.player.ui.AlbumArt
import com.aurora.player.ui.AuroraTheme
import com.aurora.player.ui.bounceClick
import com.aurora.player.ui.dominantColor
import com.aurora.player.ui.rememberArt
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

/** Aurora's own lock-screen player: drawn over the system lock screen while music is playing. */
class LockScreenActivity : ComponentActivity() {
    private val unlocked = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            finish()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED)
        }
        enableEdgeToEdge()
        ContextCompat.registerReceiver(this, unlocked, IntentFilter(Intent.ACTION_USER_PRESENT), ContextCompat.RECEIVER_NOT_EXPORTED)
        setContent {
            AuroraTheme(2) { LockContent(controller, onUnlock = ::unlock) }
        }
    }

    private fun unlock() {
        val km = getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        if (!km.isKeyguardLocked) {
            finish()
            return
        }
        km.requestDismissKeyguard(this, object : KeyguardManager.KeyguardDismissCallback() {
            override fun onDismissSucceeded() { finish() }
        })
    }

    override fun onDestroy() {
        try { unregisterReceiver(unlocked) } catch (_: Exception) {}
        super.onDestroy()
    }
}

@Composable
private fun LockContent(c: PlayerController, onUnlock: () -> Unit) {
    val ctx = LocalContext.current
    val track = c.current
    val bmp = rememberArt(track)
    val accent by animateColorAsState(bmp?.dominantColor() ?: Color(0xFF4A3F8F), tween(800), label = "lockAccent")

    val now by produceState(System.currentTimeMillis()) {
        while (true) { value = System.currentTimeMillis(); delay(10_000) }
    }
    val time = remember(now) { DateFormat.getTimeFormat(ctx).format(Date(now)) }
    val date = remember(now) { SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(Date(now)) }

    val bob = rememberInfiniteTransition(label = "bob")
    val bobY by bob.animateFloat(0f, -14f, infiniteRepeatable(tween(900), RepeatMode.Reverse), label = "bobY")

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.75f), Color(0xFF0B0A12), Color(0xFF0B0A12))))
            .pointerInput(Unit) {
                var total = 0f
                detectVerticalDragGestures(
                    onDragStart = { total = 0f },
                    onDragEnd = { if (total < -180f) onUnlock(); total = 0f },
                ) { _, dy -> total += dy }
            },
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 26.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            Text(time, color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light, modifier = Modifier.padding(top = 18.dp))
            Text(date, color = Color.White.copy(alpha = 0.75f), fontSize = 15.sp)

            Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 18.dp), contentAlignment = Alignment.Center) {
                val scale by animateFloatAsState(if (c.isPlaying) 1f else 0.9f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "lockArt")
                AnimatedContent(
                    track?.id,
                    transitionSpec = { (scaleIn(tween(450), 0.85f) + fadeIn(tween(450))) togetherWith (scaleOut(tween(300), 0.85f) + fadeOut(tween(250))) },
                    label = "lockArtSwap",
                ) {
                    AlbumArt(track, Modifier.fillMaxWidth(0.8f).aspectRatio(1f).scale(scale), RoundedCornerShape(30.dp), 72.dp)
                }
            }

            AnimatedContent(
                track?.id,
                transitionSpec = {
                    (slideInVertically(tween(350)) { it / 2 } + fadeIn(tween(350))) togetherWith
                        (slideOutVertically(tween(250)) { -it / 2 } + fadeOut(tween(200)))
                },
                label = "lockTitle",
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(track?.title ?: "Nothing playing", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(track?.artist ?: "", color = Color.White.copy(alpha = 0.7f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }

            // current lyric line
            val lyr = c.lyrics
            if (c.store.data.lockShowLyrics && lyr != null && lyr.synced) {
                val idx = lyr.indexAt(c.positionMs)
                val line = lyr.lines.getOrNull(idx)?.text.orEmpty()
                Crossfade(line, animationSpec = tween(350), label = "lockLyric", modifier = Modifier.padding(top = 10.dp).height(48.dp)) { l ->
                    Text(
                        l.ifBlank { "♪" }, color = Color.White,
                        fontSize = 16.sp, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center, maxLines = 2,
                        overflow = TextOverflow.Ellipsis,
                    )
                }
            } else {
                Spacer(Modifier.height(58.dp))
            }

            var drag by remember { mutableStateOf<Float?>(null) }
            val dur = c.durationMs.coerceAtLeast(1L).toFloat()
            Slider(
                value = (drag ?: c.positionMs.toFloat()).coerceIn(0f, dur),
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { c.seekTo(it.toLong()) }; drag = null },
                valueRange = 0f..dur,
            )
            Row(Modifier.fillMaxWidth()) {
                Text(formatTime((drag ?: c.positionMs.toFloat()).toLong()), color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp, modifier = Modifier.weight(1f))
                Text(formatTime(c.durationMs), color = Color.White.copy(alpha = 0.7f), fontSize = 12.sp)
            }

            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
            ) {
                LockIcon(Icons.Rounded.Shuffle, if (c.shuffle) Color.White else Color.White.copy(alpha = 0.45f)) { c.toggleShuffle() }
                LockIcon(Icons.Rounded.SkipPrevious, Color.White, 40.dp) { c.previous() }
                Box(
                    Modifier.size(72.dp).clip(CircleShape).background(Color.White).bounceClick { c.togglePlay() },
                    contentAlignment = Alignment.Center,
                ) {
                    AnimatedContent(
                        c.isPlaying,
                        transitionSpec = { (scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn()) togetherWith (scaleOut() + fadeOut()) },
                        label = "lockPlay",
                    ) { p -> Icon(if (p) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, tint = Color(0xFF0B0A12), modifier = Modifier.size(40.dp)) }
                }
                LockIcon(Icons.Rounded.SkipNext, Color.White, 40.dp) { c.next() }
                LockIcon(
                    if (c.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    if (c.repeatMode != Player.REPEAT_MODE_OFF) Color.White else Color.White.copy(alpha = 0.45f),
                ) { c.cycleRepeat() }
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                if (track != null) {
                    val fav = c.store.isFavourite(track.id)
                    LockIcon(
                        if (fav) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder,
                        if (fav) MaterialTheme.colorScheme.primary else Color.White.copy(alpha = 0.7f),
                    ) { c.store.toggleFavourite(track.id) }
                }
            }

            Column(Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 10.dp).offset { IntOffset(0, bobY.roundToInt()) }, horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Rounded.KeyboardArrowUp, null, tint = Color.White.copy(alpha = 0.6f))
                Text("Swipe up to unlock", color = Color.White.copy(alpha = 0.6f), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun LockIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, size: androidx.compose.ui.unit.Dp = 28.dp, onClick: () -> Unit) {
    Box(Modifier.size(52.dp).bounceClick(onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(size))
    }
}
