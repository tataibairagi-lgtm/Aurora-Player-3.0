package com.aurora.player.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.FileDownload
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.NewReleases
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material.icons.rounded.TrendingUp
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

sealed interface Route {
    object Library : Route
    data class Detail(val kind: String, val key: String) : Route
    object Queue : Route
    object Equalizer : Route
    object Settings : Route
    object MostPlayed : Route
}

/** Items fade/slide/scale in one after another the first time they appear. */
fun Modifier.staggerIn(index: Int): Modifier = composed {
    val a = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        delay(index.coerceAtMost(12) * 35L)
        a.animateTo(1f, tween(380, easing = FastOutSlowInEasing))
    }
    graphicsLayer {
        alpha = a.value
        translationY = (1f - a.value) * 36f
        val s = 0.93f + 0.07f * a.value
        scaleX = s; scaleY = s
    }
}

private enum class Sort(val label: String) {
    Title("Title"), Artist("Artist"), Album("Album"), Added("Recently added"), Length("Duration")
}

private val tabs = listOf("Tracks", "Albums", "Artists", "Folders", "Playlists", "Favourites")

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun LibraryScreen(c: PlayerController, push: (Route) -> Unit) {
    val pager = rememberPagerState { tabs.size }
    val scope = rememberCoroutineScope()
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var sort by remember { mutableStateOf(Sort.Title) }
    var sortMenu by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(start = 20.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Aurora", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            HeaderIcon(if (searching) Icons.Rounded.Close else Icons.Rounded.Search) {
                searching = !searching
                if (!searching) query = ""
            }
            Box {
                HeaderIcon(Icons.Rounded.Sort) { sortMenu = true }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    Sort.values().forEach { s ->
                        DropdownMenuItem(
                            text = { Text(s.label, fontWeight = if (s == sort) FontWeight.Bold else FontWeight.Normal) },
                            onClick = { sort = s; sortMenu = false },
                        )
                    }
                }
            }
            HeaderIcon(Icons.Rounded.Shuffle) {
                if (c.library.isNotEmpty()) c.playTracks(c.library.shuffled(), 0, true)
            }
            HeaderIcon(Icons.Rounded.Settings) { push(Route.Settings) }
        }
        AnimatedVisibility(searching, enter = expandVertically() + fadeIn(), exit = shrinkVertically() + fadeOut()) {
            OutlinedTextField(
                query, { query = it }, singleLine = true, placeholder = { Text("Search songs, artists, albums") },
                shape = RoundedCornerShape(28.dp),
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
            )
        }
        ScrollableTabRow(
            selectedTabIndex = pager.currentPage, edgePadding = 12.dp,
            containerColor = androidx.compose.ui.graphics.Color.Transparent, divider = {},
        ) {
            tabs.forEachIndexed { i, name ->
                Tab(
                    selected = pager.currentPage == i,
                    onClick = { scope.launch { pager.animateScrollToPage(i) } },
                    text = { Text(name, fontWeight = if (pager.currentPage == i) FontWeight.Bold else FontWeight.Medium) },
                )
            }
        }
        HorizontalPager(pager, Modifier.fillMaxSize(), beyondViewportPageCount = 1) { page ->
            when (page) {
                0 -> TracksTab(c, query, sort)
                1 -> AlbumsTab(c, query, push)
                2 -> ArtistsTab(c, query, push)
                3 -> FoldersTab(c, query, push)
                4 -> PlaylistsTab(c, push)
                5 -> {
                    val favs = c.store.data.favourites.mapNotNull { c.track(it) }
                    TrackList(c, favs.filter { matches(it, query) }, "No favourites yet. Use the ⋮ menu on a song.")
                }
                else -> {}
            }
        }
    }
}

@Composable
private fun HeaderIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Box(Modifier.size(44.dp).bounceClick(onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.onSurface)
    }
}

private fun matches(t: Track, q: String) =
    q.isBlank() || t.title.contains(q, true) || t.artist.contains(q, true) || t.album.contains(q, true)

@Composable
private fun Empty(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(32.dp))
    }
}

@Composable
fun TrackList(
    c: PlayerController,
    tracks: List<Track>,
    emptyText: String,
    extraMenu: (Track) -> List<Pair<String, () -> Unit>> = { emptyList() },
) {
    if (tracks.isEmpty()) { Empty(emptyText); return }
    LazyColumn(contentPadding = PaddingValues(bottom = 140.dp, top = 4.dp)) {
        itemsIndexed(tracks, key = { _, t -> t.id }) { i, t ->
            TrackRow(t, c, Modifier.animateItem(), extraMenu(t)) { c.playTracks(tracks, i) }
        }
    }
}

@Composable
private fun TracksTab(c: PlayerController, query: String, sort: Sort) {
    val list = remember(c.library, query, sort) {
        val f = c.library.filter { matches(it, query) }
        when (sort) {
            Sort.Title -> f.sortedBy { it.title.lowercase() }
            Sort.Artist -> f.sortedWith(compareBy({ it.artist.lowercase() }, { it.album.lowercase() }, { it.trackNo }))
            Sort.Album -> f.sortedWith(compareBy({ it.album.lowercase() }, { it.trackNo }))
            Sort.Added -> f.sortedByDescending { it.dateAdded }
            Sort.Length -> f.sortedByDescending { it.durationMs }
        }
    }
    TrackList(c, list, if (c.library.isEmpty()) "No music found on this device." else "No matches.")
}

@Composable
private fun AlbumsTab(c: PlayerController, query: String, push: (Route) -> Unit) {
    val albums = remember(c.library, query) {
        c.library.filter { matches(it, query) }
            .groupBy { if (it.albumId > 0) it.albumId.toString() else it.album }
            .values.sortedBy { it.first().album.lowercase() }
    }
    if (albums.isEmpty()) { Empty("No albums."); return }
    LazyVerticalGrid(
        GridCells.Fixed(2), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 140.dp),
        horizontalArrangement = Arrangement.spacedBy(14.dp), verticalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        itemsIndexed(albums, key = { _, a -> a.first().albumId.toString() + a.first().album }) { i, tracks ->
            val first = tracks.first()
            Column(
                Modifier.staggerIn(i).clip(RoundedCornerShape(18.dp))
                    .clickable { push(Route.Detail("album", if (first.albumId > 0) first.albumId.toString() else first.album)) },
            ) {
                AlbumArt(first, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(18.dp), 40.dp)
                Text(first.album, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
                Text(
                    "${first.artist} · ${tracks.size} songs", maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
private fun GroupRow(
    index: Int, title: String, subtitle: String, art: Track?, icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
    modifier: Modifier = Modifier, onClick: () -> Unit,
) {
    Row(
        modifier.staggerIn(index).fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp)
            .clip(RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (icon != null) {
            Box(
                Modifier.size(52.dp).clip(RoundedCornerShape(14.dp)),
                contentAlignment = Alignment.Center,
            ) {
                AlbumArt(null, Modifier.fillMaxSize(), RoundedCornerShape(14.dp))
                Icon(icon, null, tint = androidx.compose.ui.graphics.Color.White)
            }
        } else {
            AlbumArt(art, Modifier.size(52.dp), CircleShape, 24.dp)
        }
        Column(Modifier.weight(1f).padding(horizontal = 14.dp)) {
            Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
            Text(subtitle, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun ArtistsTab(c: PlayerController, query: String, push: (Route) -> Unit) {
    val artists = remember(c.library, query) {
        c.library.filter { matches(it, query) }.groupBy { it.artist }.toSortedMap(String.CASE_INSENSITIVE_ORDER).entries.toList()
    }
    if (artists.isEmpty()) { Empty("No artists."); return }
    LazyColumn(contentPadding = PaddingValues(bottom = 140.dp)) {
        itemsIndexed(artists, key = { _, e -> e.key }) { i, e ->
            GroupRow(i, e.key, "${e.value.size} songs", e.value.first(), Modifier.animateItem()) { push(Route.Detail("artist", e.key)) }
        }
    }
}

@Composable
private fun FoldersTab(c: PlayerController, query: String, push: (Route) -> Unit) {
    val folders = remember(c.library, query) {
        c.library.filter { matches(it, query) }.groupBy { it.folder }.entries.sortedBy { it.key.lowercase() }
    }
    if (folders.isEmpty()) { Empty("No folders."); return }
    LazyColumn(contentPadding = PaddingValues(bottom = 140.dp)) {
        itemsIndexed(folders, key = { _, e -> e.key }) { i, e ->
            GroupRow(i, e.key.substringAfterLast('/').ifEmpty { "/" }, "${e.value.size} songs · ${e.key}", null, Icons.Rounded.Folder, Modifier.animateItem()) {
                push(Route.Detail("folder", e.key))
            }
        }
    }
}

@Composable
private fun PlaylistsTab(c: PlayerController, push: (Route) -> Unit) {
    var creating by remember { mutableStateOf(false) }
    val actions = LocalActions.current
    val pls = c.store.data.playlists
    LazyColumn(contentPadding = PaddingValues(bottom = 140.dp)) {
        item {
            Column {
                GroupRow(0, "Recently added", "Last 100 songs", null, Icons.Rounded.AutoAwesome) { push(Route.Detail("smart", "added")) }
                GroupRow(1, "Recently played", "Pick up where you left off", null, Icons.Rounded.History) { push(Route.Detail("smart", "played")) }
                GroupRow(2, "Most played", "By week, month, year, all time, and by artist", null, Icons.Rounded.TrendingUp) { push(Route.MostPlayed) }
                GroupRow(3, "Not played yet", "Songs you have never listened to", null, Icons.Rounded.NewReleases) { push(Route.Detail("smart", "unplayed")) }
                GroupRow(4, "New playlist", "Create an empty playlist", null, Icons.Rounded.Add) { creating = true }
                GroupRow(5, "Import playlist file", ".m3u / .m3u8 / .pls, e.g. exported from Musicolet", null, Icons.Rounded.FileDownload) { actions.importPlaylist() }
            }
        }
        itemsIndexed(pls, key = { _, p -> p.id }) { i, p ->
            GroupRow(i + 6, p.name, "${p.trackIds.size} songs", null, Icons.AutoMirrored.Rounded.PlaylistAdd, Modifier.animateItem()) {
                push(Route.Detail("playlist", p.id))
            }
        }
    }
    if (creating) NameDialog("New playlist", confirm = "Create", onDismiss = { creating = false }) {
        c.store.createPlaylist(it); creating = false
    }
}

// -------------------------------------------------------------------------------------------------
// Detail (album / artist / folder / playlist / smart list)
// -------------------------------------------------------------------------------------------------

@Composable
fun DetailScreen(c: PlayerController, kind: String, key: String, back: () -> Unit) {
    val d = c.store.data
    val playlist = if (kind == "playlist") d.playlists.find { it.id == key } else null
    val (title, tracks) = remember(kind, key, c.library, d.playlists, d.playCounts, d.lastPlayed) {
        when (kind) {
            "album" -> {
                val l = c.library.filter { (if (it.albumId > 0) it.albumId.toString() else it.album) == key }
                (l.firstOrNull()?.album ?: "Album") to l.sortedBy { it.trackNo }
            }
            "artist" -> key to c.library.filter { it.artist == key }.sortedBy { it.album.lowercase() + "%03d".format(it.trackNo) }
            "folder" -> key.substringAfterLast('/') to c.library.filter { it.folder == key }.sortedBy { it.title.lowercase() }
            "playlist" -> (playlist?.name ?: "Playlist") to (playlist?.trackIds?.mapNotNull { c.track(it) } ?: emptyList())
            else -> when (key) {
                "added" -> "Recently added" to c.library.sortedByDescending { it.dateAdded }.take(100)
                "played" -> "Recently played" to d.lastPlayed.mapNotNull { c.track(it) }
                "unplayed" -> "Not played yet" to c.library.filter { (d.playCounts[it.id] ?: 0) == 0 }.sortedBy { it.title.lowercase() }
                else -> "Most played" to d.playCounts.entries.sortedByDescending { it.value }.take(100).mapNotNull { c.track(it.key) }
            }
        }
    }
    var menu by remember { mutableStateOf(false) }
    var rename by remember { mutableStateOf(false) }
    var saveAs by remember { mutableStateOf(false) }
    val actions = LocalActions.current

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            HeaderIcon(Icons.AutoMirrored.Rounded.ArrowBack, back)
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Box {
                HeaderIcon(Icons.Rounded.MoreVert) { menu = true }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text("Add all to queue") }, onClick = { menu = false; c.addAllToQueue(tracks) })
                    DropdownMenuItem(text = { Text("Export as .m3u") }, onClick = { menu = false; actions.exportPlaylist(title, tracks) })
                    if (playlist != null) {
                        DropdownMenuItem(text = { Text("Rename") }, onClick = { menu = false; rename = true })
                        DropdownMenuItem(text = { Text("Delete playlist") }, onClick = { menu = false; c.store.deletePlaylist(playlist.id); back() })
                    } else {
                        DropdownMenuItem(text = { Text("Save as playlist") }, onClick = { menu = false; saveAs = true })
                    }
                }
            }
        }
        Row(Modifier.padding(horizontal = 20.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(tracks.firstOrNull(), Modifier.size(96.dp), RoundedCornerShape(20.dp), 40.dp)
            Column(Modifier.padding(start = 16.dp)) {
                Text("${tracks.size} songs · ${formatTime(tracks.sumOf { it.durationMs })}", color = MaterialTheme.colorScheme.onSurfaceVariant)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Play", Icons.Rounded.PlayArrow, true) { c.playTracks(tracks, 0, false) }
                    PillButton("Shuffle", Icons.Rounded.Shuffle, false) { c.playTracks(tracks.shuffled(), 0, true) }
                }
            }
        }
        TrackList(
            c, tracks, "Nothing here yet.",
            extraMenu = { t ->
                if (playlist != null) listOf("Remove from playlist" to { c.store.removeFromPlaylist(playlist.id, t.id) }) else emptyList()
            },
        )
    }
    if (rename && playlist != null) NameDialog("Rename playlist", playlist.name, "Rename", { rename = false }) {
        c.store.renamePlaylist(playlist.id, it); rename = false
    }
    if (saveAs) NameDialog("Save as playlist", title, "Save", { saveAs = false }) {
        c.store.createPlaylist(it, tracks.map { t -> t.id }); saveAs = false
    }
}

@Composable
fun PillButton(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, filled: Boolean, onClick: () -> Unit) {
    val bg = if (filled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceVariant
    val fg = if (filled) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface
    Row(
        Modifier.clip(RoundedCornerShape(50)).then(Modifier.bounceClick(onClick))
            .background(bg).padding(horizontal = 16.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(18.dp))
        Spacer(Modifier.size(6.dp))
        Text(label, color = fg, fontWeight = FontWeight.SemiBold)
    }
}
