package com.aurora.player.player

import android.app.Application
import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.audiofx.Virtualizer
import android.os.Build
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.aurora.player.data.EqPreset
import com.aurora.player.data.EqProfile
import com.aurora.player.data.LyricsRepo
import com.aurora.player.data.PlayLog
import com.aurora.player.widget.WidgetUpdater
import com.aurora.player.data.Lyrics
import com.aurora.player.data.QueueData
import com.aurora.player.data.Store
import com.aurora.player.data.Track
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.math.min

class EqBand(val freqHz: Int, val minMb: Int, val maxMb: Int)

const val OUT_SPEAKER = "speaker"
const val OUT_WIRED = "wired"
const val OUT_BLUETOOTH = "bluetooth"
const val OUT_OTHER = "other"
val OUTPUTS = listOf(
    OUT_SPEAKER to "Speaker",
    OUT_WIRED to "Headphones",
    OUT_BLUETOOTH to "Bluetooth",
    OUT_OTHER to "Other",
)

/**
 * Single source of truth for playback. Owns the ExoPlayer (also used by [PlaybackService] for the
 * notification / media session) and exposes everything the UI needs as Compose state.
 */
class PlayerController(
    private val app: Application,
    val store: Store,
    val lyricsRepo: LyricsRepo,
) {
    val player: ExoPlayer = ExoPlayer.Builder(app)
        .setAudioAttributes(
            AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                .build(),
            true,
        )
        .setHandleAudioBecomingNoisy(true)
        .setWakeMode(C.WAKE_MODE_LOCAL)
        .build()

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    val playLog = PlayLog(app)
    private val handler = Handler(Looper.getMainLooper())

    // ---- library ----
    var library by mutableStateOf<List<Track>>(emptyList()); private set
    private var byId: Map<Long, Track> = emptyMap()
    fun track(id: Long): Track? = byId[id]

    // ---- queue / now playing ----
    var queue by mutableStateOf<List<Track>>(emptyList()); private set
    var currentIndex by mutableIntStateOf(-1); private set
    var current by mutableStateOf<Track?>(null); private set
    var activeQueue by mutableIntStateOf(0); private set

    // ---- transport ----
    var isPlaying by mutableStateOf(false); private set
    var positionMs by mutableLongStateOf(0L); private set
    var durationMs by mutableLongStateOf(0L); private set
    var shuffle by mutableStateOf(false); private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF); private set
    var speed by mutableFloatStateOf(1f); private set
    var pitch by mutableFloatStateOf(1f); private set

    // ---- sleep timer / A-B ----
    var sleepLeftMs by mutableLongStateOf(0L); private set
    var sleepAfterTrack by mutableStateOf(false); private set
    private var sleepEndsAt = 0L
    var abA by mutableLongStateOf(-1L); private set
    var abB by mutableLongStateOf(-1L); private set

    // ---- lyrics ----
    var lyrics by mutableStateOf<Lyrics?>(null); private set
    var lyricsLoading by mutableStateOf(false); private set
    var overlayActive by mutableStateOf(false)
    private var lyricsJob: Job? = null

    // ---- effects ----
    private var eq: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var loudnessFx: LoudnessEnhancer? = null
    private var virtualizer: Virtualizer? = null
    var eqBands by mutableStateOf<List<EqBand>>(emptyList()); private set
    var eqSystemPresets by mutableStateOf<List<String>>(emptyList()); private set
    var activeOutput by mutableStateOf(OUT_SPEAKER); private set
    private val audioManager = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    val bassAvailable: Boolean get() = bassBoost?.strengthSupported == true
    val virtualizerAvailable: Boolean get() = virtualizer?.strengthSupported == true

    private var countedThisTrack = false
    private var lastSave = 0L

    init {
        val d = store.data
        activeQueue = d.activeQueue.coerceIn(0, d.queues.lastIndex)
        speed = d.speed
        pitch = d.pitch
        player.playbackParameters = PlaybackParameters(speed, pitch)

        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                this@PlayerController.isPlaying = isPlaying
                if (isPlaying) startTicker()
                WidgetUpdater.update(app)
            }

            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (sleepAfterTrack) {
                    sleepAfterTrack = false
                    player.pauseAtEndOfMediaItems = false
                }
                clearAB()
                countedThisTrack = false
                syncCurrent()
                persistSoon()
                WidgetUpdater.update(app)
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                durationMs = player.duration.coerceAtLeast(0)
            }

            override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
                shuffle = shuffleModeEnabled
                WidgetUpdater.update(app)
            }

            override fun onRepeatModeChanged(repeatMode: Int) {
                this@PlayerController.repeatMode = repeatMode
                WidgetUpdater.update(app)
            }

            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                initEffects(audioSessionId)
            }
        })
        activeOutput = detectOutput()
        audioManager.registerAudioDeviceCallback(object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>?) = refreshOutput()
            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>?) = refreshOutput()
        }, handler)
        initEffects(player.audioSessionId)
    }

    // ---------------------------------------------------------------------------------------------
    // Library / queue
    // ---------------------------------------------------------------------------------------------

    fun attachLibrary(list: List<Track>) {
        library = list
        byId = list.associateBy { it.id }
        if (player.mediaItemCount == 0) {
            val q = store.data.queues.getOrNull(activeQueue) ?: return
            val tracks = q.trackIds.mapNotNull { byId[it] }
            if (tracks.isNotEmpty()) {
                setQueue(tracks, q.index.coerceIn(0, tracks.lastIndex), q.positionMs, false)
            }
        }
    }

    private fun item(t: Track): MediaItem {
        val md = MediaMetadata.Builder()
            .setTitle(t.title)
            .setArtist(t.artist)
            .setAlbumTitle(t.album)
        if (t.albumId > 0) {
            md.setArtworkUri(Uri.parse("content://media/external/audio/albumart/${t.albumId}"))
        }
        return MediaItem.Builder()
            .setMediaId(t.id.toString())
            .setUri(t.uri)
            .setMediaMetadata(md.build())
            .build()
    }

    private fun setQueue(list: List<Track>, start: Int, pos: Long, play: Boolean) {
        queue = list
        if (list.isEmpty()) {
            player.clearMediaItems()
        } else {
            player.setMediaItems(list.map(::item), start.coerceIn(0, list.lastIndex), pos)
            player.prepare()
            if (play) player.play()
        }
        syncCurrent()
        persistSoon()
    }

    fun playTracks(list: List<Track>, start: Int = 0, shuffleOn: Boolean? = null) {
        if (list.isEmpty()) return
        shuffleOn?.let { player.shuffleModeEnabled = it }
        setQueue(list, start, 0L, true)
    }

    fun playNext(t: Track) {
        if (queue.isEmpty()) { playTracks(listOf(t)); return }
        val at = (player.currentMediaItemIndex + 1).coerceAtMost(queue.size)
        player.addMediaItem(at, item(t))
        queue = queue.toMutableList().also { it.add(at, t) }
        persistSoon()
    }

    fun addToQueue(t: Track) = addAllToQueue(listOf(t))

    fun addAllToQueue(list: List<Track>) {
        if (list.isEmpty()) return
        if (queue.isEmpty()) { playTracks(list); return }
        player.addMediaItems(list.map(::item))
        queue = queue + list
        persistSoon()
    }

    fun removeAt(index: Int) {
        if (index !in queue.indices) return
        player.removeMediaItem(index)
        queue = queue.toMutableList().also { it.removeAt(index) }
        syncCurrent()
        persistSoon()
    }

    fun move(from: Int, to: Int) {
        if (from !in queue.indices || to !in queue.indices || from == to) return
        player.moveMediaItem(from, to)
        queue = queue.toMutableList().also { it.add(to, it.removeAt(from)) }
        syncCurrent()
        persistSoon()
    }

    fun clearQueue() {
        player.pause()
        player.clearMediaItems()
        queue = emptyList()
        syncCurrent()
        persistSoon()
    }

    fun jumpTo(index: Int) {
        if (index !in queue.indices) return
        player.seekTo(index, 0)
        player.play()
    }

    fun switchQueue(i: Int) {
        if (i == activeQueue || i !in store.data.queues.indices) return
        saveActiveQueue()
        activeQueue = i
        store.update { it.copy(activeQueue = i) }
        val q = store.data.queues[i]
        val tracks = q.trackIds.mapNotNull { byId[it] }
        player.pause()
        if (tracks.isEmpty()) {
            player.clearMediaItems()
            queue = emptyList()
            syncCurrent()
        } else {
            setQueue(tracks, q.index.coerceIn(0, tracks.lastIndex), q.positionMs, false)
        }
    }

    /** Rebuilds the player's queue from the stored queues (used after restoring a backup). */
    fun reloadQueueFromStore() {
        val d = store.data
        activeQueue = d.activeQueue.coerceIn(0, d.queues.lastIndex)
        val q = d.queues.getOrNull(activeQueue) ?: return
        val tracks = q.trackIds.mapNotNull { byId[it] }
        player.pause()
        if (tracks.isEmpty()) {
            player.clearMediaItems()
            queue = emptyList()
            syncCurrent()
        } else {
            setQueue(tracks, q.index.coerceIn(0, tracks.lastIndex), q.positionMs, false)
        }
    }

    private fun saveActiveQueue() {
        val data = QueueData(
            name = store.data.queues.getOrNull(activeQueue)?.name ?: "Queue",
            trackIds = queue.map { it.id },
            index = player.currentMediaItemIndex.coerceAtLeast(0),
            positionMs = player.currentPosition,
        )
        store.update { p ->
            p.copy(queues = p.queues.toMutableList().also { if (activeQueue in it.indices) it[activeQueue] = data })
        }
    }

    private val persistRunnable = Runnable { saveActiveQueue() }
    private fun persistSoon() {
        handler.removeCallbacks(persistRunnable)
        handler.postDelayed(persistRunnable, 800)
    }

    private fun syncCurrent() {
        currentIndex = if (queue.isEmpty()) -1 else player.currentMediaItemIndex
        val t = queue.getOrNull(currentIndex)
        val changed = t?.id != current?.id
        current = t
        durationMs = if (t != null) player.duration.coerceAtLeast(0).let { if (it == 0L) t.durationMs else it } else 0
        positionMs = if (t != null) player.currentPosition else 0
        if (changed) loadLyrics(t)
    }

    // ---------------------------------------------------------------------------------------------
    // Transport
    // ---------------------------------------------------------------------------------------------

    fun togglePlay() { if (player.isPlaying) player.pause() else player.play() }
    fun next() { player.seekToNextMediaItem() }
    fun previous() {
        if (player.currentPosition > 3000) player.seekTo(0) else player.seekToPreviousMediaItem()
    }
    fun seekTo(ms: Long) {
        player.seekTo(ms)
        positionMs = ms
    }
    fun toggleShuffle() { player.shuffleModeEnabled = !player.shuffleModeEnabled }
    fun cycleRepeat() {
        player.repeatMode = when (player.repeatMode) {
            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
            else -> Player.REPEAT_MODE_OFF
        }
    }

    fun setSpeedPitch(s: Float, p: Float) {
        speed = s; pitch = p
        player.playbackParameters = PlaybackParameters(s, p)
        store.update { it.copy(speed = s, pitch = p) }
    }

    fun setFadeSeconds(s: Int) = store.update { it.copy(fadeSec = s) }

    // ---- A-B repeat ----
    fun markAB() {
        when {
            abA < 0 -> abA = player.currentPosition
            abB < 0 -> {
                if (player.currentPosition > abA + 500) abB = player.currentPosition else abA = player.currentPosition
            }
            else -> clearAB()
        }
    }

    fun clearAB() { abA = -1; abB = -1 }

    // ---- sleep timer ----
    fun setSleepMinutes(min: Int) {
        sleepAfterTrack = false
        player.pauseAtEndOfMediaItems = false
        sleepEndsAt = SystemClock.elapsedRealtime() + min * 60_000L
        sleepLeftMs = min * 60_000L
        startTicker()
    }

    fun setSleepEndOfTrack() {
        sleepEndsAt = 0; sleepLeftMs = 0
        sleepAfterTrack = true
        player.pauseAtEndOfMediaItems = true
    }

    fun cancelSleep() {
        sleepEndsAt = 0; sleepLeftMs = 0
        sleepAfterTrack = false
        player.pauseAtEndOfMediaItems = false
        player.volume = 1f
    }

    // ---------------------------------------------------------------------------------------------
    // Ticker: position, A-B, fade, sleep, play counts
    // ---------------------------------------------------------------------------------------------

    private var ticking = false
    private val ticker = object : Runnable {
        override fun run() {
            positionMs = player.currentPosition
            val dur = player.duration
            if (dur > 0) durationMs = dur

            if (abA >= 0 && abB > abA && positionMs >= abB) player.seekTo(abA)

            var vol = 1f
            val f = store.data.fadeSec * 1000L
            if (f > 0 && durationMs > 0) {
                val fade = min(f, durationMs / 3)
                if (fade > 0) {
                    if (positionMs < fade) vol = min(vol, positionMs / fade.toFloat())
                    val remaining = durationMs - positionMs
                    if (remaining < fade) vol = min(vol, remaining / fade.toFloat())
                }
            }
            if (sleepEndsAt > 0) {
                val left = (sleepEndsAt - SystemClock.elapsedRealtime()).coerceAtLeast(0)
                sleepLeftMs = left
                if (left < 8000) vol = min(vol, left / 8000f)
                if (left == 0L) {
                    sleepEndsAt = 0
                    player.pause()
                    vol = 1f
                }
            }
            player.volume = vol.coerceIn(0f, 1f)

            val t = current
            if (t != null && !countedThisTrack && positionMs >= 15_000) {
                countedThisTrack = true
                store.recordPlay(t.id)
                playLog.append(t.id)
            }
            val now = SystemClock.elapsedRealtime()
            if (now - lastSave > 5000 && player.isPlaying) {
                lastSave = now
                saveActiveQueue()
            }

            if (player.isPlaying || sleepEndsAt > 0) handler.postDelayed(this, 100) else ticking = false
        }
    }

    private fun startTicker() {
        if (ticking) return
        ticking = true
        handler.post(ticker)
    }

    // ---------------------------------------------------------------------------------------------
    // Lyrics
    // ---------------------------------------------------------------------------------------------

    private fun loadLyrics(t: Track?, force: Boolean = false) {
        lyricsJob?.cancel()
        lyrics = null
        if (t == null) return
        lyricsJob = scope.launch {
            lyricsLoading = true
            lyrics = lyricsRepo.load(t, store.data.onlineLyrics || force, force)
            lyricsLoading = false
        }
    }

    fun importLyrics(text: String) {
        val t = current ?: return
        lyricsRepo.save(t, text)
        loadLyrics(t)
    }

    fun refetchLyrics() = loadLyrics(current, force = true)


    // ---------------------------------------------------------------------------------------------
    // Effects: one equalizer profile per audio output, switched automatically like Musicolet
    // ---------------------------------------------------------------------------------------------

    private fun detectOutput(): String {
        val types = try {
            audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS).map { it.type }
        } catch (_: Exception) {
            emptyList()
        }
        val bt = types.any {
            it == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || it == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                (Build.VERSION.SDK_INT >= 31 && (it == AudioDeviceInfo.TYPE_BLE_HEADSET || it == AudioDeviceInfo.TYPE_BLE_SPEAKER))
        }
        val wired = types.any {
            it == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || it == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                it == AudioDeviceInfo.TYPE_USB_HEADSET
        }
        val other = types.any {
            it == AudioDeviceInfo.TYPE_HDMI || it == AudioDeviceInfo.TYPE_USB_DEVICE ||
                it == AudioDeviceInfo.TYPE_USB_ACCESSORY || it == AudioDeviceInfo.TYPE_LINE_ANALOG ||
                it == AudioDeviceInfo.TYPE_LINE_DIGITAL || it == AudioDeviceInfo.TYPE_AUX_LINE
        }
        return when {
            bt -> OUT_BLUETOOTH
            wired -> OUT_WIRED
            other -> OUT_OTHER
            else -> OUT_SPEAKER
        }
    }

    private fun refreshOutput() {
        val o = detectOutput()
        if (o != activeOutput) {
            activeOutput = o
            applyActiveProfile()
        }
    }

    private fun initEffects(session: Int) {
        try { eq?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        try { loudnessFx?.release() } catch (_: Exception) {}
        eq = null; bassBoost = null; virtualizer = null; loudnessFx = null
        if (session == C.AUDIO_SESSION_ID_UNSET || session == 0) return
        try {
            val e = Equalizer(0, session)
            val range = e.bandLevelRange
            eqBands = (0 until e.numberOfBands).map {
                EqBand(e.getCenterFreq(it.toShort()) / 1000, range[0].toInt(), range[1].toInt())
            }
            eqSystemPresets = (0 until e.numberOfPresets).map { e.getPresetName(it.toShort()) }
            eq = e
        } catch (_: Exception) {
        }
        try { bassBoost = BassBoost(0, session) } catch (_: Exception) {}
        try { virtualizer = Virtualizer(0, session) } catch (_: Exception) {}
        try { loudnessFx = LoudnessEnhancer(session) } catch (_: Exception) {}
        applyActiveProfile()
    }

    /** Profile for [key], with band levels sized to this device's band count. */
    fun profile(key: String): EqProfile {
        val p = store.data.eqProfiles[key] ?: EqProfile()
        val n = eqBands.size
        return if (n > 0 && p.levels.size != n) p.copy(levels = List(n) { 0 }) else p
    }

    fun editProfile(key: String, f: (EqProfile) -> EqProfile) {
        val next = f(profile(key))
        store.update { it.copy(eqProfiles = it.eqProfiles + (key to next)) }
        if (key == activeOutput) applyActiveProfile()
    }

    private fun applyActiveProfile() {
        val p = profile(activeOutput)
        val on = p.enabled
        try {
            eq?.let { e ->
                val r = e.bandLevelRange
                p.levels.forEachIndexed { i, l ->
                    if (i < e.numberOfBands) e.setBandLevel(i.toShort(), l.coerceIn(r[0].toInt(), r[1].toInt()).toShort())
                }
                e.enabled = on
            }
        } catch (_: Exception) {
        }
        try {
            bassBoost?.let { b ->
                if (b.strengthSupported) b.setStrength(p.bass.coerceIn(0, 1000).toShort())
                b.enabled = on && p.bass > 0
            }
        } catch (_: Exception) {
        }
        try {
            virtualizer?.let { v ->
                if (v.strengthSupported) v.setStrength(p.virtualizer.coerceIn(0, 1000).toShort())
                v.enabled = on && p.virtualizer > 0
            }
        } catch (_: Exception) {
        }
        try {
            loudnessFx?.let { l ->
                l.setTargetGain(p.loudness.coerceIn(0, 1500))
                l.enabled = on && p.loudness > 0
            }
        } catch (_: Exception) {
        }
    }

    /** Band levels of one of the device's built-in presets. */
    fun systemPresetLevels(index: Int): List<Int>? {
        val e = eq ?: return null
        return try {
            e.usePreset(index.toShort())
            val l = (0 until e.numberOfBands).map { e.getBandLevel(it.toShort()).toInt() }
            applyActiveProfile() // put the live equalizer back to the active profile
            l
        } catch (_: Exception) {
            null
        }
    }

    /** Re-applies the stored equalizer profile (after settings were restored from a backup). */
    fun reapplyEffects() = applyActiveProfile()

    fun saveCustomPreset(name: String, levels: List<Int>) {
        val n = name.trim()
        if (n.isEmpty()) return
        store.update { it.copy(customPresets = it.customPresets.filter { p -> p.name != n } + EqPreset(n, levels)) }
    }

    fun deleteCustomPreset(name: String) =
        store.update { it.copy(customPresets = it.customPresets.filter { p -> p.name != name }) }

    // ---- widget helpers ----
    fun toggleFavouriteCurrent() {
        current?.let { store.toggleFavourite(it.id) }
    }
}
