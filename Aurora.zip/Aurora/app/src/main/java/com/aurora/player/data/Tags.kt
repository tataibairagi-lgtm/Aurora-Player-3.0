package com.aurora.player.data

import android.content.Context
import android.net.Uri
import org.jaudiotagger.audio.AudioFileIO
import org.jaudiotagger.tag.FieldKey
import java.io.File
import java.util.logging.Level
import java.util.logging.Logger

/** The tags Aurora can show and edit. */
data class TagData(
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val albumArtist: String = "",
    val genre: String = "",
    val year: String = "",
    val track: String = "",
    val lyrics: String = "",
)

/** Reads and writes real tags inside the audio file (MP3, M4A, FLAC, OGG, WAV…) using jaudiotagger. */
object TagIo {
    init {
        try { Logger.getLogger("org.jaudiotagger").level = Level.OFF } catch (_: Exception) {}
    }

    private fun ext(t: Track) = t.path.substringAfterLast('.', "mp3").lowercase().ifEmpty { "mp3" }

    /** A readable File for the song: its real path when allowed, otherwise a temporary copy. */
    private fun fileFor(ctx: Context, t: Track): Pair<File, Boolean> {
        val direct = File(t.path)
        if (t.path.isNotEmpty() && direct.canRead()) return direct to false
        val tmp = File(ctx.cacheDir, "tag_read_${t.id}.${ext(t)}")
        ctx.contentResolver.openInputStream(Uri.parse(t.uri))!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
        return tmp to true
    }

    fun read(ctx: Context, t: Track): TagData {
        val (f, temp) = try { fileFor(ctx, t) } catch (_: Exception) { return fallback(t) }
        return try {
            val tag = AudioFileIO.read(f).tag ?: return fallback(t)
            fun g(k: FieldKey) = try { tag.getFirst(k) ?: "" } catch (_: Exception) { "" }
            TagData(
                title = g(FieldKey.TITLE).ifEmpty { t.title },
                artist = g(FieldKey.ARTIST).ifEmpty { t.artist },
                album = g(FieldKey.ALBUM).ifEmpty { t.album },
                albumArtist = g(FieldKey.ALBUM_ARTIST),
                genre = g(FieldKey.GENRE).ifEmpty { t.genre },
                year = g(FieldKey.YEAR),
                track = g(FieldKey.TRACK),
                lyrics = g(FieldKey.LYRICS),
            )
        } catch (_: Throwable) {
            fallback(t)
        } finally {
            if (temp) f.delete()
        }
    }

    private fun fallback(t: Track) = TagData(title = t.title, artist = t.artist, album = t.album, genre = t.genre)

    /** Lyrics stored inside the audio file (ID3 USLT, Vorbis LYRICS, MP4 ©lyr), or null. */
    fun embeddedLyrics(ctx: Context, t: Track): String? {
        val (f, temp) = try { fileFor(ctx, t) } catch (_: Exception) { return null }
        return try {
            val s = AudioFileIO.read(f).tag?.getFirst(FieldKey.LYRICS)
            if (s.isNullOrBlank()) null else s
        } catch (_: Throwable) {
            null
        } finally {
            if (temp) f.delete()
        }
    }

    /** Writes [d] into [file] (a copy with the same extension as the song). Throws on unsupported files. */
    fun write(file: File, d: TagData) {
        val af = AudioFileIO.read(file)
        val tag = af.tagOrCreateAndSetDefault
        fun put(k: FieldKey, v: String) {
            if (v.isBlank()) { try { tag.deleteField(k) } catch (_: Exception) {} } else tag.setField(k, v)
        }
        put(FieldKey.TITLE, d.title)
        put(FieldKey.ARTIST, d.artist)
        put(FieldKey.ALBUM, d.album)
        put(FieldKey.ALBUM_ARTIST, d.albumArtist)
        put(FieldKey.GENRE, d.genre)
        put(FieldKey.YEAR, d.year)
        put(FieldKey.TRACK, d.track)
        put(FieldKey.LYRICS, d.lyrics)
        af.commit()
    }
}
