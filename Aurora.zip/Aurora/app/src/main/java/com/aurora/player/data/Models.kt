package com.aurora.player.data

import kotlinx.serialization.Serializable

data class Track(
    val id: Long,
    val uri: String,
    val title: String,
    val artist: String,
    val album: String,
    val albumId: Long,
    val durationMs: Long,
    val path: String,
    val dateAdded: Long,
    val trackNo: Int,
    val genre: String = "",
) {
    val folder: String get() = path.substringBeforeLast('/', "")
    val folderName: String get() = folder.substringAfterLast('/')
}

@Serializable
data class Playlist(val id: String, val name: String, val trackIds: List<Long> = emptyList())

@Serializable
data class QueueData(
    val name: String,
    val trackIds: List<Long> = emptyList(),
    val index: Int = 0,
    val positionMs: Long = 0,
)

data class LyricLine(val timeMs: Long, val text: String)

class Lyrics(val lines: List<LyricLine>, val synced: Boolean)

/** Index of the line that should be highlighted at [posMs], or -1 before the first line. */
fun Lyrics.indexAt(posMs: Long): Int {
    if (!synced) return -1
    var lo = 0
    var hi = lines.lastIndex
    var ans = -1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (lines[mid].timeMs <= posMs) { ans = mid; lo = mid + 1 } else hi = mid - 1
    }
    return ans
}

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    val h = s / 3600
    val m = (s % 3600) / 60
    val sec = s % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
}

/** One equalizer setup. Musicolet keeps a separate one per audio output (speaker, headphones, Bluetooth...). */
@Serializable
data class EqProfile(
    val enabled: Boolean = false,
    val levels: List<Int> = emptyList(),
    val bass: Int = 0,        // 0..1000
    val virtualizer: Int = 0, // 0..1000
    val loudness: Int = 0,    // millibels of extra gain, 0..1500
    val preset: String = "Custom",
)

@Serializable
data class EqPreset(val name: String, val levels: List<Int>)
