package com.aurora.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.player.player.PlayerController

@Composable
fun AuroraRoot(c: PlayerController, route: String? = null, onRouteHandled: () -> Unit = {}) {
    var stack by remember { mutableStateOf<List<Route>>(listOf(Route.Library)) }
    var showNow by remember { mutableStateOf(false) }
    val prevSize = remember { mutableIntStateOf(1) }
    val pushing = stack.size >= prevSize.intValue
    SideEffect { prevSize.intValue = stack.size }

    LaunchedEffect(route) {
        when (route) {
            "queue" -> { showNow = false; stack = listOf(Route.Library, Route.Queue) }
            "now" -> showNow = true
        }
        if (route != null) onRouteHandled()
    }

    BackHandler(enabled = showNow) { showNow = false }
    BackHandler(enabled = !showNow && stack.size > 1) { stack = stack.dropLast(1) }

    val push = { r: Route -> stack = stack + r }
    val pop = { stack = stack.dropLast(1) }

    Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        AnimatedContent(
            stack.last(),
            transitionSpec = {
                if (pushing) {
                    (slideInHorizontally(tween(360, easing = FastOutSlowInEasing)) { it / 3 } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(360, easing = FastOutSlowInEasing)) { -it / 5 } + fadeOut(tween(220)))
                } else {
                    (slideInHorizontally(tween(360, easing = FastOutSlowInEasing)) { -it / 5 } + fadeIn(tween(320))) togetherWith
                        (slideOutHorizontally(tween(360, easing = FastOutSlowInEasing)) { it / 3 } + fadeOut(tween(220)))
                }
            },
            label = "nav",
        ) { route ->
            when (route) {
                Route.Library -> LibraryScreen(c, push)
                is Route.Detail -> DetailScreen(c, route.kind, route.key, pop)
                Route.Queue -> QueueScreen(c, pop)
                Route.Equalizer -> EqualizerScreen(c, pop)
                Route.Settings -> SettingsScreen(c, pop)
                Route.MostPlayed -> MostPlayedScreen(c, push, pop)
            }
        }

        AnimatedVisibility(
            c.current != null && !showNow,
            modifier = Modifier.align(Alignment.BottomCenter),
            enter = slideInVertically(spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMediumLow)) { it } + fadeIn(),
            exit = slideOutVertically(tween(250)) { it } + fadeOut(tween(200)),
        ) {
            MiniPlayer(c) { showNow = true }
        }

        BackupDialogs()

        AnimatedVisibility(
            showNow,
            enter = slideInVertically(tween(480, easing = FastOutSlowInEasing)) { it } + fadeIn(tween(300)),
            exit = slideOutVertically(tween(380, easing = FastOutSlowInEasing)) { it } + fadeOut(tween(300)),
        ) {
            NowPlayingScreen(
                c, onClose = { showNow = false },
                openQueue = { showNow = false; push(Route.Queue) },
                openEq = { showNow = false; push(Route.Equalizer) },
            )
        }
    }
}

@Composable
private fun MiniPlayer(c: PlayerController, onOpen: () -> Unit) {
    val t = c.current ?: return
    val progress = if (c.durationMs > 0) (c.positionMs.toFloat() / c.durationMs).coerceIn(0f, 1f) else 0f
    Column(
        Modifier.navigationBarsPadding().padding(horizontal = 12.dp, vertical = 10.dp)
            .shadow(14.dp, RoundedCornerShape(24.dp))
            .clip(RoundedCornerShape(24.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .clickable(onClick = onOpen),
    ) {
        Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            AlbumArt(t, Modifier.size(46.dp), CircleShape, 22.dp)
            AnimatedContent(
                t.id, Modifier.weight(1f).padding(horizontal = 12.dp),
                transitionSpec = {
                    (slideInVertically(tween(300)) { it / 2 } + fadeIn(tween(300))) togetherWith
                        (slideOutVertically(tween(200)) { -it / 2 } + fadeOut(tween(150)))
                },
                label = "miniTitle",
            ) {
                Column {
                    Text(t.title, maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Text(t.artist, maxLines = 1, overflow = TextOverflow.Ellipsis, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            Box(Modifier.size(44.dp).bounceClick { c.togglePlay() }, contentAlignment = Alignment.Center) {
                AnimatedContent(
                    c.isPlaying,
                    transitionSpec = { (androidx.compose.animation.scaleIn() + fadeIn()) togetherWith (androidx.compose.animation.scaleOut() + fadeOut()) },
                    label = "miniPlay",
                ) { p -> Icon(if (p) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null, modifier = Modifier.size(30.dp)) }
            }
            Box(Modifier.size(44.dp).bounceClick { c.next() }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.SkipNext, null, modifier = Modifier.size(28.dp))
            }
        }
        LinearProgressIndicator(
            progress = { progress }, modifier = Modifier.fillMaxWidth(),
            trackColor = MaterialTheme.colorScheme.surfaceVariant,
        )
    }
}
