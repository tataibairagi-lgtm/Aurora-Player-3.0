package com.aurora.player.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File

class PlayEvent(val at: Long, val id: Long)

/**
 * Every counted play with its timestamp, kept in a small append-only file.
 * This is what makes "most played this week / month / year" and per-artist rankings possible.
 */
class PlayLog(ctx: Context) {
    private val file = File(ctx.filesDir, "plays.log")

    var events by mutableStateOf(load())
        private set

    private fun load(): List<PlayEvent> = try {
        if (!file.exists()) emptyList()
        else file.readLines().mapNotNull { line ->
            val p = line.split(',')
            val at = p.getOrNull(0)?.toLongOrNull()
            val id = p.getOrNull(1)?.toLongOrNull()
            if (p.size == 2 && at != null && id != null) PlayEvent(at, id) else null
        }
    } catch (_: Exception) {
        emptyList()
    }

    fun append(id: Long) {
        val e = PlayEvent(System.currentTimeMillis(), id)
        events = events + e
        try { file.appendText("${e.at},${e.id}\n") } catch (_: Exception) {}
    }

    fun replaceAll(list: List<PlayEvent>) {
        events = list
        try { file.writeText(list.joinToString("") { "${it.at},${it.id}\n" }) } catch (_: Exception) {}
    }
}
