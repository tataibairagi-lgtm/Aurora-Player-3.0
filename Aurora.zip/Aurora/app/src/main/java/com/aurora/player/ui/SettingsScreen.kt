package com.aurora.player.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aurora.player.backup.BackupScheduler
import com.aurora.player.lyrics.LyricsOverlayService
import com.aurora.player.widget.WidgetUpdater
import com.aurora.player.player.PlayerController
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(c: PlayerController, back: () -> Unit) {
    val d = c.store.data
    val ctx = LocalContext.current
    val actions = LocalActions.current

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().verticalScroll(rememberScrollState())) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).bounceClick(back), contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Text("Settings", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        Section("Appearance")
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("System", "Light", "Dark").forEachIndexed { i, n ->
                FilterChip(d.themeMode == i, { c.store.update { it.copy(themeMode = i) } }, label = { Text(n) })
            }
        }
        SwitchRow("Spinning vinyl album art", "Off = a breathing square cover", d.discArt) { v -> c.store.update { it.copy(discArt = v) } }

        Section("Desktop lyrics")
        SwitchRow("Show floating lyrics", "Draws over other apps. Needs “display over other apps” permission.", c.overlayActive) {
            actions.toggleOverlay(it)
        }
        SwitchRow("Lock position", "Makes the window touch-through. Turn off here to move it again.", d.overlayLocked) {
            LyricsOverlayService.setLocked(ctx, it)
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Row {
                Text("Text size", Modifier.weight(1f))
                Text("${d.overlayTextSp} sp", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            Slider(d.overlayTextSp.toFloat(), { v -> c.store.update { it.copy(overlayTextSp = v.roundToInt()) } }, valueRange = 12f..48f)
            Text("Colour")
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(0xFFFFFFFF, 0xFFFFE066, 0xFF7FE3D0, 0xFFFF8FB1, 0xFF9CFF8A, 0xFFB4A8FF).forEach { col ->
                    val sel = d.overlayColor == col
                    Box(
                        Modifier.size(34.dp).background(Color(col), CircleShape)
                            .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                            .bounceClick { c.store.update { it.copy(overlayColor = col) } },
                    )
                }
            }
        }

        Section("Lyrics sources")
        SwitchRow("Fetch missing lyrics from LRCLIB", "Only when a song has none. Downloads are saved for offline use.", d.onlineLyrics) { v ->
            c.store.update { it.copy(onlineLyrics = v) }
        }
        ActionRow("Read .lrc files next to songs", "Grants all-files access so “song.mp3” can use “song.lrc” in the same folder.") {
            if (Build.VERSION.SDK_INT >= 30) {
                ctx.startActivity(
                    Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            }
        }

        Section("Library")
        ActionRow("Rescan music", "${c.library.size} songs found") { actions.rescan() }

        Section("Backup & restore")
        val folderLabel = if (d.backupFolder.isEmpty()) "Not set, tap to choose where backups are saved"
        else (Uri.parse(d.backupFolder).lastPathSegment ?: "Chosen folder").replace(':', '/')
        ActionRow("Backup folder", folderLabel) { actions.chooseBackupFolder() }
        ActionRow("Backup now", "Last backup: ${formatDateTime(ctx, d.lastBackupAt)}") { actions.backupNow() }
        SwitchRow(
            "Automatic backup", "Saves a new zip in the background and keeps only the latest ones",
            d.autoBackup && d.backupFolder.isNotEmpty(),
        ) { on ->
            if (on && d.backupFolder.isEmpty()) actions.chooseBackupFolder()
            c.store.update { it.copy(autoBackup = on) }
            BackupScheduler.apply(ctx, c.store.data)
        }
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Every", Modifier.padding(end = 4.dp))
            listOf(1 to "Day", 7 to "Week", 30 to "Month").forEach { (days, name) ->
                FilterChip(d.autoBackupDays == days, {
                    c.store.update { it.copy(autoBackupDays = days) }
                    BackupScheduler.apply(ctx, c.store.data)
                }, label = { Text(name) })
            }
        }
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Keep last", Modifier.padding(end = 4.dp))
            listOf(3, 5, 10).forEach { n ->
                FilterChip(d.autoBackupKeep == n, { c.store.update { it.copy(autoBackupKeep = n) } }, label = { Text("$n") })
            }
        }
        ActionRow("Restore from backup", "Choose what to restore: settings, favourites, playlists, play counts, queues, lyrics") { actions.openRestore() }

        Section("Lock screen")
        SwitchRow(
            "Lock-screen player",
            "Shows a full player over the lock screen when music is playing and the screen turns off. Needs “display over other apps”.",
            d.lockScreenPlayer,
        ) { on ->
            if (on && !actions.ensureOverlayPermission()) return@SwitchRow
            c.store.update { it.copy(lockScreenPlayer = on) }
        }
        SwitchRow("Show lyrics on lock screen", "Current line under the cover", d.lockShowLyrics) { v ->
            c.store.update { it.copy(lockShowLyrics = v) }
        }

        Section("Queue widget")
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Wallpaper", "Light", "Dark").forEachIndexed { i, n ->
                FilterChip(d.queueTheme == i, {
                    c.store.update { it.copy(queueTheme = i) }
                    WidgetUpdater.update(ctx)
                }, label = { Text(n) })
            }
        }
        Text(
            "“Wallpaper” takes its colours from your home-screen wallpaper (Material You colours on Android 12+).",
            Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Section("About")
        Text(
            "Aurora keeps playing in the background with lock-screen controls, gapless playback, two switchable queues, " +
                "playlists, favourites, equalizer, bass boost, speed/pitch, sleep timer, A–B repeat and floating lyrics.",
            Modifier.padding(horizontal = 20.dp), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Box(Modifier.height(32.dp))
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title, Modifier.padding(start = 20.dp, top = 22.dp, bottom = 6.dp),
        style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
    )
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun ActionRow(title: String, sub: String, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp)) {
        Text(title, fontWeight = FontWeight.Medium)
        Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
