package com.aurora.player.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aurora.player.backup.BackupScheduler
import com.aurora.player.lyrics.LyricsOverlayService
import com.aurora.player.player.PlayerController
import com.aurora.player.widget.WidgetUpdater
import kotlin.math.roundToInt

private val PAGES = listOf(
    Triple("interface", "Interface", "Theme, tabs, Now Playing background"),
    Triple("audio", "Audio", "Fades, audio focus, volume, equalizer"),
    Triple("headset", "Headset, Bluetooth and speaker", "Pause and resume when devices connect"),
    Triple("library", "Song library and tags", "Excluded folders, short files, scan"),
    Triple("advanced", "Advanced", "Playback behaviour, positions, fast-forward"),
    Triple("lyrics", "Lyrics", "Embedded, .lrc file or online"),
    Triple("desktop", "Desktop lyrics", "Floating lyrics window"),
    Triple("backup", "Backup & restore", "Zip backups, automatic backup"),
    Triple("lock", "Lock screen and widgets", "Lock-screen player, queue widget theme"),
    Triple("about", "About", ""),
)

@Composable
fun SettingsScreen(c: PlayerController, back: () -> Unit, openEq: () -> Unit) {
    var page by remember { mutableStateOf<String?>(null) }
    BackHandler(enabled = page != null) { page = null }
    val title = PAGES.firstOrNull { it.first == page }?.second ?: "Settings"

    Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).bounceClick { if (page != null) page = null else back() }, contentAlignment = Alignment.Center) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, null)
            }
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            when (page) {
                null -> PAGES.forEach { (id, name, sub) -> ActionRow(name, sub) { page = id } }
                "interface" -> InterfacePage(c)
                "audio" -> AudioPage(c, openEq)
                "headset" -> HeadsetPage(c)
                "library" -> LibraryPage(c)
                "advanced" -> AdvancedPage(c)
                "lyrics" -> LyricsPage(c)
                "desktop" -> DesktopPage(c)
                "backup" -> BackupPage(c)
                "lock" -> LockPage(c)
                else -> AboutPage()
            }
            Box(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun InterfacePage(c: PlayerController) {
    val d = c.store.data
    val actions = LocalActions.current
    var arrange by remember { mutableStateOf(false) }
    if (arrange) ArrangeTabsDialog(c) { arrange = false }

    ChipRow("Theme") {
        listOf("System", "Light", "Dark", "Black").forEachIndexed { i, n ->
            FilterChip(d.themeMode == i, { c.store.update { it.copy(themeMode = i) } }, label = { Text(n) })
        }
    }
    Column(Modifier.padding(horizontal = 20.dp, vertical = 6.dp)) {
        Text("Accent colour")
        Text(
            "Default uses your phone's colours (Android 12+) or Aurora purple.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Row(Modifier.padding(vertical = 8.dp).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            listOf(0L, 0xFF7C5CFF, 0xFF2EA8FF, 0xFF1ED6B4, 0xFF55C95A, 0xFFFFB300, 0xFFFF6E40, 0xFFFF4F8B).forEach { col ->
                val sel = d.accentColor == col
                Box(
                    Modifier.size(34.dp)
                        .background(if (col == 0L) MaterialTheme.colorScheme.surfaceVariant else Color(col), CircleShape)
                        .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.onSurface else Color.Gray, CircleShape)
                        .bounceClick { c.store.update { it.copy(accentColor = col) } },
                    contentAlignment = Alignment.Center,
                ) { if (col == 0L) Text("A", style = MaterialTheme.typography.labelLarge) }
            }
        }
    }
    ChipRow("Tab-bar position") {
        listOf(false to "Top", true to "Bottom").forEach { (b, n) ->
            FilterChip(d.tabsBottom == b, { c.store.update { it.copy(tabsBottom = b) } }, label = { Text(n) })
        }
    }
    ActionRow("Arrange tabs", "Arrange tabs, or enable/disable them") { arrange = true }
    SwitchRow("Spinning vinyl album art", "Off = a breathing square cover", d.discArt) { v -> c.store.update { it.copy(discArt = v) } }
    SwitchRow("Confirm before exit", "Ask when pressing back on the first tab", d.confirmExit) { v -> c.store.update { it.copy(confirmExit = v) } }

    Section("Now playing")
    ChipRow("Background") {
        listOf("Album colour", "Blurred art", "Aurora", "Plain", "Black", "My image").forEachIndexed { i, n ->
            FilterChip(d.nowBg == i, {
                if (i == 5 && d.customBgUri.isEmpty()) actions.pickBackground() else c.store.update { it.copy(nowBg = i) }
            }, label = { Text(n) })
        }
    }
    if (d.nowBg == 5) ActionRow("Choose image", "Pick the picture shown behind the player") { actions.pickBackground() }
    if (d.nowBg == 1 || d.nowBg == 5) {
        Column(Modifier.padding(horizontal = 20.dp)) {
            Row {
                Text("Darken background", Modifier.weight(1f))
                Text("${d.nowBgDim}%", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            Slider(d.nowBgDim.toFloat(), { v -> c.store.update { it.copy(nowBgDim = v.roundToInt()) } }, valueRange = 0f..80f)
        }
    }
    Text(
        "Tip: tap the palette icon on the Now Playing screen to cycle through backgrounds.",
        Modifier.padding(horizontal = 20.dp, vertical = 2.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    SwitchRow("Keep screen on", "While the Now Playing screen is open", d.keepScreenOn) { v -> c.store.update { it.copy(keepScreenOn = v) } }
}

@Composable
private fun AudioPage(c: PlayerController, openEq: () -> Unit) {
    val d = c.store.data
    ActionRow("Equalizer", "Per-output equalizer, bass boost, virtualizer, loudness, speed and pitch") { openEq() }
    Column(Modifier.padding(horizontal = 20.dp, vertical = 8.dp)) {
        Row {
            Text("Audio focus", Modifier.weight(1f), fontWeight = FontWeight.Medium)
            Text("Level ${d.focusLevel}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Slider(
            d.focusLevel.toFloat(), { v -> c.store.update { it.copy(focusLevel = v.roundToInt().coerceIn(1, 5)) }; c.applyPlaybackPrefs() },
            valueRange = 1f..5f, steps = 3,
        )
        val lvl = d.focusLevel
        fun line(on: Boolean, text: String) = (if (on) "✓ " else "✗ ") + text
        Text(
            listOf(
                line(lvl >= 2, "Pause music during phone calls"),
                line(lvl >= 3, "Pause music when another app plays audio for a long time (music, video)"),
                line(lvl == 4, "Lower the volume for short sounds: navigation prompts, notification sounds"),
                line(lvl >= 5, "Pause (instead of lowering the volume) for short sounds too"),
                if (lvl == 1) "Level 1: Aurora ignores calls and other apps completely." else "",
            ).filter { it.isNotEmpty() }.joinToString("\n"),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(top = 4.dp),
        )
    }
    SwitchRow("Resume after call ends", "Resume after a call or a short interruption ends", d.resumeAfterCall) { v ->
        c.store.update { it.copy(resumeAfterCall = v) }
    }
    SwitchRow("Skip silence", "Skips silent gaps within songs", d.skipSilence) { v ->
        c.store.update { it.copy(skipSilence = v) }; c.applyPlaybackPrefs()
    }
    SliderSetting("Fade between songs", d.fadeSec.toFloat(), 0f..12f, 11, if (d.fadeSec == 0) "Off" else "${d.fadeSec} s") { v ->
        c.store.update { it.copy(fadeSec = v.roundToInt()) }
    }
    SliderSetting("Fade-in volume when play", d.fadeInMs.toFloat(), 0f..2000f, 19, "${d.fadeInMs} ms") { v ->
        c.store.update { it.copy(fadeInMs = (v / 100).roundToInt() * 100) }
    }
    SliderSetting("Fade-out volume when pause", d.fadeOutMs.toFloat(), 0f..2000f, 19, "${d.fadeOutMs} ms") { v ->
        c.store.update { it.copy(fadeOutMs = (v / 100).roundToInt() * 100) }
    }
    Section("Volume")
    SwitchRow("Do not allow playback if audio volume is 0", "Shows a message instead of playing silently", d.blockPlayMuted) { v ->
        c.store.update { it.copy(blockPlayMuted = v) }
    }
    SwitchRow("Pause when audio is muted", "Pauses when the media volume reaches 0", d.pauseOnMute) { v -> c.store.update { it.copy(pauseOnMute = v) } }
    SwitchRow("Resume when audio is un-muted", "Only if playback was paused because it was muted", d.resumeOnUnmute) { v ->
        c.store.update { it.copy(resumeOnUnmute = v) }
    }
    Text(
        "Gapless playback is always on.", Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun HeadsetPage(c: PlayerController) {
    val d = c.store.data
    Section("Pause when disconnect")
    SwitchRow("Pause when disconnect", "Pause music when headset, speaker or Bluetooth is disconnected", d.pauseOnUnplug) { v ->
        c.store.update { it.copy(pauseOnUnplug = v) }; c.applyPlaybackPrefs()
    }
    Section("Resume when connect")
    SwitchRow("Resume only if paused by disconnection before", "", d.resumeOnlyIfPaused) { v -> c.store.update { it.copy(resumeOnlyIfPaused = v) } }
    SwitchRow("Resume on Bluetooth connect", "", d.resumeOnBt) { v -> c.store.update { it.copy(resumeOnBt = v) } }
    SwitchRow("Resume on wired headset / speaker connect", "", d.resumeOnWired) { v -> c.store.update { it.copy(resumeOnWired = v) } }
    Section("Earphone's mic button")
    Text(
        "Single press: play / pause. Double press: next song. Triple press: previous song. " +
            "Some phones don't send earphone button presses to music apps.",
        Modifier.padding(horizontal = 20.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun LibraryPage(c: PlayerController) {
    val d = c.store.data
    val actions = LocalActions.current
    var foldersDialog by remember { mutableStateOf(false) }
    if (foldersDialog) ExcludedFoldersDialog(c, { foldersDialog = false }) { actions.rescan() }

    Section("Song library")
    ActionRow(
        "Excluded folders",
        if (d.excludedFolders.isEmpty()) "None. Hide folders (voice notes, ringtones…) from Aurora" else "${d.excludedFolders.size} hidden",
    ) { foldersDialog = true }
    ChipRow("Exclude small duration files") {
        listOf(0, 15, 30, 60, 120).forEach { sec ->
            FilterChip(d.minDurationSec == sec, {
                c.store.update { it.copy(minDurationSec = sec) }; actions.rescan()
            }, label = { Text(if (sec == 0) "None" else if (sec < 60) "$sec s" else "${sec / 60} min") })
        }
    }
    Section("Scan")
    ActionRow("Scan", "${c.library.size} songs found. Aurora also scans every time it starts") { actions.rescan() }
    Section("Tags, album art, lyrics")
    SwitchRow("Load album arts", "If disabled, album art is not loaded anywhere in the app", d.loadArt) { v ->
        c.store.update { it.copy(loadArt = v) }; ArtLoader.enabled = v
    }
    SwitchRow("Show file names instead of titles", "Shows each song's file name everywhere", d.showFileNames) { v ->
        c.store.update { it.copy(showFileNames = v) }; actions.rescan()
    }
    Text(
        "Edit tags: open a song's ⋮ menu and choose “Edit tags”. Title, artist, album, album artist, genre, year, track and " +
            "embedded lyrics are written into the audio file.",
        Modifier.padding(horizontal = 20.dp, vertical = 8.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun AdvancedPage(c: PlayerController) {
    val d = c.store.data
    SwitchRow("Stop playing and close the app when removed from recents", "", d.stopOnTaskRemoved) { v -> c.store.update { it.copy(stopOnTaskRemoved = v) } }
    SwitchRow("Start playback when app is started", "Resumes your last queue automatically", d.autoPlayOnStart) { v -> c.store.update { it.copy(autoPlayOnStart = v) } }
    SwitchRow("Remember last positions of all tracks", "Useful for big songs, podcasts and audiobooks (10+ minutes)", d.rememberPositions) { v ->
        c.store.update { it.copy(rememberPositions = v) }
    }
    ChipRow("Minimum duration for considering a playback") {
        listOf(5, 10, 15, 30, 60).forEach { sec ->
            FilterChip(d.minPlaySec == sec, { c.store.update { it.copy(minPlaySec = sec) } }, label = { Text("$sec s") })
        }
    }
    SwitchRow("Previous button restarts the song", "After the first 3 seconds, tapping previous goes back to the start", d.prevRestarts) { v ->
        c.store.update { it.copy(prevRestarts = v) }
    }
    SwitchRow("Tapping a song plays the whole list", "Off = plays only that song", d.tapPlaysList) { v -> c.store.update { it.copy(tapPlaysList = v) } }
    ChipRow("Fast-forward duration") {
        listOf(5, 10, 15, 30).forEach { sec ->
            FilterChip(d.ffSec == sec, { c.store.update { it.copy(ffSec = sec) } }, label = { Text("$sec s") })
        }
    }
    ChipRow("Rewind duration") {
        listOf(5, 10, 15, 30).forEach { sec ->
            FilterChip(d.rewindSec == sec, { c.store.update { it.copy(rewindSec = sec) } }, label = { Text("$sec s") })
        }
    }
    Section("Queues")
    SwitchRow(
        "Open a queue named after the source",
        "Playing an album, playlist, folder… uses (or creates) a queue with that name. You can keep up to 20 queues.", d.sourceQueues,
    ) { v -> c.store.update { it.copy(sourceQueues = v) } }
    ChipRow("If a queue with that name already exists") {
        listOf(false to "Replace it", true to "Merge into it").forEach { (m, n) ->
            FilterChip(d.queueMerge == m, { c.store.update { it.copy(queueMerge = m) } }, label = { Text(n) })
        }
    }
    Section("Sort")
    SwitchRow("Ignore certain words at beginning while sorting", "Ignores “A”, “An”, “The” when sorting songs, albums and artists", d.ignoreWords) { v ->
        c.store.update { it.copy(ignoreWords = v) }
    }
}

@Composable
private fun LyricsPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    ChipRow("Preferred source of lyrics") {
        listOf("embedded" to "Embedded in song", "file" to "Lyrics file (.lrc)", "saved" to "Saved / imported").forEach { (id, n) ->
            FilterChip(d.lyricsPreferred == id, { c.store.update { it.copy(lyricsPreferred = id) } }, label = { Text(n) })
        }
    }
    Text(
        "When several sources have lyrics, the preferred one is used first. To choose a source for one song, tap the album art on the Now Playing screen " +
            "to open the lyrics, then tap “Source”. Aurora has no internet access, so lyrics come only from the song's tags, a .lrc file or ones you import.",
        Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
    ActionRow("Read .lrc files next to songs", "Grants all-files access so “song.mp3” can use “song.lrc” in the same folder (Android 11+).") {
        if (Build.VERSION.SDK_INT >= 30) {
            ctx.startActivity(
                Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:${ctx.packageName}"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        }
    }
}

@Composable
private fun DesktopPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    val actions = LocalActions.current
        SwitchRow("Show floating lyrics", "Draws over other apps. Needs “display over other apps” permission.", c.overlayActive) {
            actions.toggleOverlay(it)
        }
        SwitchRow("Lock position", "Makes the window touch-through. Turn off here to move it again.", d.overlayLocked) {
            LyricsOverlayService.setLocked(ctx, it)
        }
        Column(Modifier.padding(horizontal = 20.dp)) {
            Row {
                Text("Text size", Modifier.weight(1f))
                Text("${d.overlayTextSp} sp", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
            }
            Slider(d.overlayTextSp.toFloat(), { v -> c.store.update { it.copy(overlayTextSp = v.roundToInt()) } }, valueRange = 12f..48f)
            Text("Colour")
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                listOf(0xFFFFFFFF, 0xFFFFE066, 0xFF7FE3D0, 0xFFFF8FB1, 0xFF9CFF8A, 0xFFB4A8FF).forEach { col ->
                    val sel = d.overlayColor == col
                    Box(
                        Modifier.size(34.dp).background(Color(col), CircleShape)
                            .border(if (sel) 3.dp else 1.dp, if (sel) MaterialTheme.colorScheme.primary else Color.Gray, CircleShape)
                            .bounceClick { c.store.update { it.copy(overlayColor = col) } },
                    )
                }
            }
        }

}

@Composable
private fun BackupPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    val actions = LocalActions.current
        val folderLabel = if (d.backupFolder.isEmpty()) "Not set, tap to choose where backups are saved"
        else (Uri.parse(d.backupFolder).lastPathSegment ?: "Chosen folder").replace(':', '/')
        ActionRow("Backup folder", folderLabel) { actions.chooseBackupFolder() }
        ActionRow("Backup now", "Last backup: ${formatDateTime(ctx, d.lastBackupAt)}") { actions.backupNow() }
        SwitchRow(
            "Automatic backup", "Saves a new zip in the background and keeps only the latest ones",
            d.autoBackup && d.backupFolder.isNotEmpty(),
        ) { on ->
            if (on && d.backupFolder.isEmpty()) actions.chooseBackupFolder()
            c.store.update { it.copy(autoBackup = on) }
            BackupScheduler.apply(ctx, c.store.data)
        }
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Every", Modifier.padding(end = 4.dp))
            listOf(1 to "Day", 7 to "Week", 30 to "Month").forEach { (days, name) ->
                FilterChip(d.autoBackupDays == days, {
                    c.store.update { it.copy(autoBackupDays = days) }
                    BackupScheduler.apply(ctx, c.store.data)
                }, label = { Text(name) })
            }
        }
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Keep last", Modifier.padding(end = 4.dp))
            listOf(3, 5, 10).forEach { n ->
                FilterChip(d.autoBackupKeep == n, { c.store.update { it.copy(autoBackupKeep = n) } }, label = { Text("$n") })
            }
        }
        ActionRow("Restore from backup", "Choose what to restore: settings, favourites, playlists, play counts, queues, lyrics") { actions.openRestore() }

}

@Composable
private fun LockPage(c: PlayerController) {
    val d = c.store.data
    val ctx = LocalContext.current
    val actions = LocalActions.current
        Section("Lock screen")
        SwitchRow(
            "Lock-screen player",
            "Shows a full player over the lock screen when music is playing and the screen turns off. Needs “display over other apps”.",
            d.lockScreenPlayer,
        ) { on ->
            if (on && !actions.ensureOverlayPermission()) return@SwitchRow
            c.store.update { it.copy(lockScreenPlayer = on) }
        }
        SwitchRow("Show lyrics on lock screen", "Current line under the cover", d.lockShowLyrics) { v ->
            c.store.update { it.copy(lockShowLyrics = v) }
        }

        Section("Queue widget")
        Row(Modifier.padding(horizontal = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Wallpaper", "Light", "Dark").forEachIndexed { i, n ->
                FilterChip(d.queueTheme == i, {
                    c.store.update { it.copy(queueTheme = i) }
                    WidgetUpdater.update(ctx)
                }, label = { Text(n) })
            }
        }
        Text(
            "“Wallpaper” takes its colours from your home-screen wallpaper (Material You colours on Android 12+).",
            Modifier.padding(horizontal = 20.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

}

@Composable
private fun AboutPage() {
    Text(
        "Aurora keeps playing in the background with lock-screen controls, gapless playback, two switchable queues, " +
            "playlists, favourites, equalizer, bass boost, speed/pitch, sleep timer, A–B repeat and floating lyrics.",
        Modifier.padding(horizontal = 20.dp, vertical = 12.dp), style = MaterialTheme.typography.bodySmall,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
}

@Composable
private fun SliderSetting(label: String, value: Float, range: ClosedFloatingPointRange<Float>, steps: Int, text: String, onChange: (Float) -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
        Row {
            Text(label, Modifier.weight(1f))
            Text(text, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
        }
        Slider(value, onChange, valueRange = range, steps = steps)
    }
}

@Composable
private fun ChipRow(label: String, content: @Composable () -> Unit) {
    Column(Modifier.padding(horizontal = 20.dp, vertical = 4.dp)) {
        Text(label)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) { content() }
    }
}

@Composable
private fun ExcludedFoldersDialog(c: PlayerController, onDismiss: () -> Unit, onChanged: () -> Unit) {
    val d = c.store.data
    androidx.compose.material3.AlertDialog(
        onDismissRequest = { onDismiss(); onChanged() },
        title = { Text("Excluded folders") },
        text = {
            androidx.compose.foundation.lazy.LazyColumn(Modifier.heightIn(max = 380.dp)) {
                if (c.allFolders.isEmpty()) item { Text("No music folders found yet.") }
                items(c.allFolders.size) { i ->
                    val f = c.allFolders[i]
                    val hidden = f in d.excludedFolders
                    Row(Modifier.fillMaxWidth().clickable {
                        c.store.update { it.copy(excludedFolders = if (hidden) it.excludedFolders - f else it.excludedFolders + f) }
                    }, verticalAlignment = Alignment.CenterVertically) {
                        androidx.compose.material3.Checkbox(hidden, null)
                        Column(Modifier.padding(start = 8.dp, top = 6.dp, bottom = 6.dp)) {
                            Text(f.substringAfterLast('/').ifEmpty { "/" }, fontWeight = FontWeight.Medium)
                            Text(f, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        },
        confirmButton = { androidx.compose.material3.TextButton({ onDismiss(); onChanged() }) { Text("Done") } },
    )
}

@Composable
private fun Section(title: String) {
    Text(
        title, Modifier.padding(start = 20.dp, top = 22.dp, bottom = 6.dp),
        style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold,
    )
}

@Composable
private fun SwitchRow(title: String, sub: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(horizontal = 20.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(title, fontWeight = FontWeight.Medium)
            Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked, onChange)
    }
}

@Composable
private fun ActionRow(title: String, sub: String, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 10.dp)) {
        Text(title, fontWeight = FontWeight.Medium)
        Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
