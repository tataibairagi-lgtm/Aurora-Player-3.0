package com.aurora.player.widget

import android.annotation.SuppressLint
import android.app.WallpaperManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.os.Build
import androidx.core.graphics.ColorUtils

/**
 * Colours for the queue widget.
 *  - Wallpaper mode on Android 12+: the system's Material You palette, which Android derives from your wallpaper.
 *  - Wallpaper mode on Android 8.1-11: the wallpaper's dominant colour, turned into a light or dark palette.
 *  - Light / Dark modes: a fixed Aurora palette.
 * Light vs dark follows the phone's dark mode in wallpaper mode.
 */
object WidgetTheme {
    class Colors(
        val header: Int, val headerAlpha: Int,
        val panel: Int, val panelAlpha: Int,
        val text: Int, val sub: Int, val accent: Int, val divider: Int,
    )

    private const val AURORA_SEED = 0xFF7C6CF0.toInt()

    fun resolve(ctx: Context, mode: Int): Colors {
        val night = (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        return when (mode) {
            1 -> fromSeed(AURORA_SEED, dark = false)
            2 -> fromSeed(AURORA_SEED, dark = true)
            else -> if (Build.VERSION.SDK_INT >= 31) dynamic(ctx, night)
            else fromSeed(wallpaperSeed(ctx) ?: AURORA_SEED, night)
        }
    }

    @SuppressLint("NewApi")
    private fun dynamic(ctx: Context, dark: Boolean): Colors {
        fun c(id: Int) = ctx.getColor(id)
        return if (!dark) Colors(
            header = c(android.R.color.system_accent1_100), headerAlpha = 0xE6,
            panel = c(android.R.color.system_accent1_50), panelAlpha = 0xCC,
            text = c(android.R.color.system_neutral1_900), sub = c(android.R.color.system_neutral2_700),
            accent = c(android.R.color.system_accent1_600), divider = c(android.R.color.system_accent1_200),
        ) else Colors(
            header = c(android.R.color.system_accent2_800), headerAlpha = 0xE6,
            panel = c(android.R.color.system_neutral1_900), panelAlpha = 0xD9,
            text = c(android.R.color.system_neutral1_100), sub = c(android.R.color.system_neutral2_300),
            accent = c(android.R.color.system_accent1_200), divider = c(android.R.color.system_accent2_700),
        )
    }

    private fun wallpaperSeed(ctx: Context): Int? {
        if (Build.VERSION.SDK_INT < 27) return null
        return try {
            WallpaperManager.getInstance(ctx).getWallpaperColors(WallpaperManager.FLAG_SYSTEM)?.primaryColor?.toArgb()
        } catch (_: Exception) {
            null
        }
    }

    private fun fromSeed(seed: Int, dark: Boolean): Colors {
        val hsl = FloatArray(3)
        ColorUtils.colorToHSL(seed, hsl)
        val h = hsl[0]
        // very grey wallpapers would give a dull palette, so keep a little colour in it
        val s = hsl[1].coerceIn(0.35f, 0.85f)
        fun hsl(sat: Float, light: Float) = ColorUtils.HSLToColor(floatArrayOf(h, sat.coerceIn(0f, 1f), light))
        return if (!dark) Colors(
            header = hsl(s * 0.75f, 0.88f), headerAlpha = 0xE6,
            panel = hsl(s * 0.8f, 0.94f), panelAlpha = 0xCC,
            text = hsl(s * 0.5f, 0.14f), sub = hsl(s * 0.35f, 0.36f),
            accent = hsl(s, 0.34f), divider = hsl(s * 0.6f, 0.78f),
        ) else Colors(
            header = hsl(s * 0.5f, 0.22f), headerAlpha = 0xE6,
            panel = hsl(s * 0.35f, 0.14f), panelAlpha = 0xD9,
            text = hsl(s * 0.3f, 0.92f), sub = hsl(s * 0.25f, 0.72f),
            accent = hsl(s, 0.76f), divider = hsl(s * 0.4f, 0.28f),
        )
    }
}
