package com.aurora.player.data

import android.content.ContentUris
import android.content.Context
import android.os.Build
import android.provider.MediaStore

object MediaScanner {
    fun hasAudioPermission(ctx: Context): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) android.Manifest.permission.READ_MEDIA_AUDIO
        else android.Manifest.permission.READ_EXTERNAL_STORAGE
        return androidx.core.content.ContextCompat.checkSelfPermission(ctx, p) ==
            android.content.pm.PackageManager.PERMISSION_GRANTED
    }

    fun scan(ctx: Context): List<Track> {
        val out = ArrayList<Track>()
        val collection = if (Build.VERSION.SDK_INT >= 29)
            MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        else MediaStore.Audio.Media.EXTERNAL_CONTENT_URI

        val proj = arrayOf(
            MediaStore.Audio.Media._ID,
            MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.ARTIST,
            MediaStore.Audio.Media.ALBUM,
            MediaStore.Audio.Media.ALBUM_ID,
            MediaStore.Audio.Media.DURATION,
            MediaStore.Audio.Media.DATA,
            MediaStore.Audio.Media.DATE_ADDED,
            MediaStore.Audio.Media.TRACK,
        )
        val sel = "${MediaStore.Audio.Media.IS_MUSIC} != 0 AND ${MediaStore.Audio.Media.DURATION} >= 30000"
        val cursor = ctx.contentResolver.query(
            collection, proj, sel, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        ) ?: return out
        cursor.use { c ->
            val iId = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val iTitle = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ALBUM_ID)
            val iDur = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            val iData = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            val iAdded = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATE_ADDED)
            val iTrack = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TRACK)
            while (c.moveToNext()) {
                val id = c.getLong(iId)
                fun clean(s: String?, fallback: String) =
                    if (s.isNullOrBlank() || s == "<unknown>") fallback else s
                out += Track(
                    id = id,
                    uri = ContentUris.withAppendedId(collection, id).toString(),
                    title = clean(c.getString(iTitle), "Unknown title"),
                    artist = clean(c.getString(iArtist), "Unknown artist"),
                    album = clean(c.getString(iAlbum), "Unknown album"),
                    albumId = c.getLong(iAlbumId),
                    durationMs = c.getLong(iDur),
                    path = c.getString(iData) ?: "",
                    dateAdded = c.getLong(iAdded),
                    trackNo = c.getInt(iTrack) % 1000,
                )
            }
        }
        return out
    }
}
