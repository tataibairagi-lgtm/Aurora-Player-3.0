package com.aurora.player.ui

import android.text.format.DateFormat
import android.text.format.Formatter
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aurora.player.backup.BackupFile
import com.aurora.player.backup.ConflictMode
import com.aurora.player.backup.LoadedBackup
import com.aurora.player.backup.RestoreOptions
import com.aurora.player.backupUi
import java.util.Date

fun formatDateTime(ctx: android.content.Context, ms: Long): String {
    if (ms <= 0) return "never"
    val d = Date(ms)
    return DateFormat.getMediumDateFormat(ctx).format(d) + " " + DateFormat.getTimeFormat(ctx).format(d)
}

/** Shown on top of every screen: busy spinner, backup list, and the "what to restore?" dialog. */
@Composable
fun BackupDialogs() {
    val ctx = LocalContext.current
    val ui = ctx.backupUi
    val actions = LocalActions.current

    if (ui.busy) {
        AlertDialog(
            onDismissRequest = {},
            confirmButton = {},
            title = { Text("Working…") },
            text = { CircularProgressIndicator() },
        )
    }
    if (ui.picker && ui.preview == null && !ui.busy) {
        AlertDialog(
            onDismissRequest = { ui.picker = false },
            title = { Text("Select a backup") },
            text = {
                Column {
                    if (ui.files.isEmpty()) {
                        Text(
                            "No backups found in your backup folder.",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    } else {
                        LazyColumn(Modifier.heightIn(max = 300.dp)) {
                            items(ui.files, key = { it.uri.toString() }) { f -> BackupRow(f) { actions.loadBackup(f.uri, f.name) } }
                        }
                    }
                }
            },
            confirmButton = { TextButton({ ui.picker = false; actions.browseBackup() }) { Text("Browse files…") } },
            dismissButton = { TextButton({ ui.picker = false }) { Text("Cancel") } },
        )
    }
    ui.preview?.let { b ->
        RestoreDialog(b, ui.previewName, onDismiss = { ui.preview = null; ui.picker = false }) { opts ->
            ui.preview = null
            ui.picker = false
            actions.applyRestore(b, opts)
        }
    }
}

@Composable
private fun BackupRow(f: BackupFile, onClick: () -> Unit) {
    val ctx = LocalContext.current
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 10.dp)) {
        Text(f.name, fontWeight = FontWeight.Medium, maxLines = 1)
        Text(
            formatDateTime(ctx, f.modified) + " · " + Formatter.formatShortFileSize(ctx, f.size),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun CheckRow(label: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!checked) }.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked, onChange)
        Column(Modifier.padding(start = 4.dp)) {
            Text(label, fontWeight = FontWeight.Medium)
            if (sub != null) Text(sub, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun RestoreDialog(b: LoadedBackup, name: String, onDismiss: () -> Unit, onRestore: (RestoreOptions) -> Unit) {
    val ctx = LocalContext.current
    val d = b.data
    var settings by remember { mutableStateOf(true) }
    var favs by remember { mutableStateOf(d.favourites.isNotEmpty()) }
    var counts by remember { mutableStateOf(d.playCounts.isNotEmpty() || d.queues.any { it.tracks.isNotEmpty() }) }
    var lyrics by remember { mutableStateOf(d.lyrics.isNotEmpty()) }
    var chosen by remember { mutableStateOf(d.playlists.map { it.name }.toSet()) }
    var mode by remember { mutableStateOf(ConflictMode.Merge) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("What to restore?") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text(
                    "$name\nCreated ${formatDateTime(ctx, d.createdAt)}",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                CheckRow("Settings & equalizer", "Replaces your current settings", settings) { settings = it }
                CheckRow("Favourites (${d.favourites.size})", "Added to your current favourites", favs) { favs = it }
                CheckRow(
                    "Play counts & queues", "Replaces current play counts, recent plays and both queues",
                    counts,
                ) { counts = it }
                CheckRow("Lyrics (${d.lyrics.size})", null, lyrics) { lyrics = it }

                if (d.playlists.isNotEmpty()) {
                    Text("Playlists", Modifier.padding(top = 12.dp), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    d.playlists.forEach { p ->
                        CheckRow(p.name, "${p.tracks.size} songs", p.name in chosen) { on ->
                            chosen = if (on) chosen + p.name else chosen - p.name
                        }
                    }
                    Text("If a playlist with the same name exists:", Modifier.padding(top = 8.dp), style = MaterialTheme.typography.labelMedium)
                    Row(Modifier.padding(vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ConflictMode.values().forEach { m ->
                            FilterChip(mode == m, { mode = m }, label = { Text(m.label) })
                        }
                    }
                    Text(mode.help, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Text(
                    "Songs are matched by file path, then by title + artist, so this also works after moving to a new phone. Songs that can't be found are skipped.",
                    Modifier.padding(top = 12.dp), style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
            }
        },
        confirmButton = {
            TextButton({ onRestore(RestoreOptions(settings, favs, chosen, mode, counts, lyrics)) }) { Text("Restore now") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}
