package com.aurora.player.data

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.serialization.Serializable
import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json
import java.util.UUID

@Serializable
data class Persisted(
    val favourites: List<Long> = emptyList(),
    val playlists: List<Playlist> = emptyList(),
    val queues: List<QueueData> = listOf(QueueData("Queue 1"), QueueData("Queue 2")),
    val activeQueue: Int = 0,
    val playCounts: Map<Long, Int> = emptyMap(),
    val lastPlayed: List<Long> = emptyList(),
    // audio
    val eqProfiles: Map<String, EqProfile> = emptyMap(),
    val customPresets: List<EqPreset> = emptyList(),
    val speed: Float = 1f,
    val pitch: Float = 1f,
    val fadeSec: Int = 0,
    // ui
    val themeMode: Int = 0, // 0 system, 1 light, 2 dark
    val discArt: Boolean = true,
    val onlineLyrics: Boolean = true,
    // desktop lyrics
    val overlayTextSp: Int = 22,
    val overlayColor: Long = 0xFFFFFFFF,
    val overlayX: Int = 0,
    val overlayY: Int = 160,
    val overlayLocked: Boolean = false,
    // lock screen player
    val lockScreenPlayer: Boolean = false,
    val lockShowLyrics: Boolean = true,
    // queue widget colours: 0 follow wallpaper, 1 light, 2 dark
    val queueTheme: Int = 0,
    // backup (device specific: never restored from a backup)
    val backupFolder: String = "",
    val autoBackup: Boolean = false,
    val autoBackupDays: Int = 1,
    val autoBackupKeep: Int = 5,
    val lastBackupAt: Long = 0,
    // library tabs (ids in display order; hidden ones are skipped)
    val tabOrder: List<String> = listOf("queues", "now", "albums", "artists", "playlists", "folders", "genres", "tracks"),
    val hiddenTabs: List<String> = listOf("genres", "tracks"),
    val tabsBottom: Boolean = false,
    // now playing background: 0 album colour, 1 blurred album art, 2 aurora gradient, 3 plain, 4 black, 5 custom image
    val nowBg: Int = 0,
    val nowBgDim: Int = 35, // 0..80 % darkening for image backgrounds
    val customBgUri: String = "",
    // appearance (themeMode 3 = black / AMOLED)
    val accentColor: Long = 0, // 0 = default / system colours
    val keepScreenOn: Boolean = false,
    // library
    val minDurationSec: Int = 30,
    val excludedFolders: List<String> = emptyList(),
    // playback
    val pauseOnUnplug: Boolean = true,
    val handleAudioFocus: Boolean = true,
    val prevRestarts: Boolean = true,
    val tapPlaysList: Boolean = true,
    val skipSilence: Boolean = false,
    val fadeInMs: Int = 0,
    val fadeOutMs: Int = 0,
    val pauseOnMute: Boolean = true,
    val resumeOnUnmute: Boolean = true,
    val blockPlayMuted: Boolean = false,
    val resumeOnBt: Boolean = false,
    val resumeOnWired: Boolean = false,
    val resumeOnlyIfPaused: Boolean = true,
    // advanced
    val stopOnTaskRemoved: Boolean = false,
    val showFileNames: Boolean = false,
    val rememberPositions: Boolean = false,
    val positions: Map<Long, Long> = emptyMap(),
    val minPlaySec: Int = 15,
    val autoPlayOnStart: Boolean = false,
    val loadArt: Boolean = true,
    val ffSec: Int = 10,
    val rewindSec: Int = 10,
    val ignoreWords: Boolean = false,
    val confirmExit: Boolean = false,
    // lyrics: preferred source "saved" | "embedded" | "file"; per-song override ("embedded"/"file"/"saved"/"online")
    val lyricsPreferred: String = "saved",
    val lyricsSource: Map<Long, String> = emptyMap(),
    // audio focus: 1 ignore everything .. 5 pause for everything
    val focusLevel: Int = 3,
    val resumeAfterCall: Boolean = true,
    // queues
    val sourceQueues: Boolean = true, // playing an album/playlist/folder... opens a queue named after it
    val queueMerge: Boolean = false, // if that queue already exists: false = replace, true = merge
    // lock screen
    val lockSwipeRight: Boolean = true,
)

/** All persisted app state. Backed by SharedPreferences (JSON) and exposed as Compose state. */
class Store(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("aurora", Context.MODE_PRIVATE)
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }

    var data by mutableStateOf(load())
        private set

    private fun load(): Persisted = try {
        prefs.getString("d", null)?.let { json.decodeFromString<Persisted>(it) } ?: Persisted()
    } catch (e: Exception) {
        Persisted()
    }

    fun update(f: (Persisted) -> Persisted) {
        data = f(data)
        prefs.edit().putString("d", json.encodeToString(data)).apply()
    }

    // favourites
    fun isFavourite(id: Long) = id in data.favourites
    fun toggleFavourite(id: Long) = update {
        it.copy(favourites = if (id in it.favourites) it.favourites - id else it.favourites + id)
    }

    // playlists
    fun createPlaylist(name: String, ids: List<Long> = emptyList()): String {
        val id = UUID.randomUUID().toString()
        update { it.copy(playlists = it.playlists + Playlist(id, name.trim().ifEmpty { "Playlist" }, ids)) }
        return id
    }

    fun renamePlaylist(id: String, name: String) = update { p ->
        p.copy(playlists = p.playlists.map { if (it.id == id) it.copy(name = name.trim().ifEmpty { it.name }) else it })
    }

    fun deletePlaylist(id: String) = update { p -> p.copy(playlists = p.playlists.filter { it.id != id }) }

    fun addToPlaylist(id: String, ids: List<Long>) = update { p ->
        p.copy(playlists = p.playlists.map {
            if (it.id == id) it.copy(trackIds = it.trackIds + ids.filter { n -> n !in it.trackIds }) else it
        })
    }

    fun removeFromPlaylist(id: String, trackId: Long) = update { p ->
        p.copy(playlists = p.playlists.map {
            if (it.id == id) it.copy(trackIds = it.trackIds - trackId) else it
        })
    }

    fun recordPlay(id: Long) = update {
        it.copy(
            playCounts = it.playCounts + (id to ((it.playCounts[id] ?: 0) + 1)),
            lastPlayed = (listOf(id) + it.lastPlayed.filter { x -> x != id }).take(100),
        )
    }
}
