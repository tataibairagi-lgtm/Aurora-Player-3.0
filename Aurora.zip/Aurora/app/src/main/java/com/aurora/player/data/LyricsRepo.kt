package com.aurora.player.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

object LrcParser {
    private val tag = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")

    fun parse(text: String): Lyrics? {
        val synced = ArrayList<LyricLine>()
        val plain = ArrayList<String>()
        for (raw in text.lines()) {
            val matches = tag.findAll(raw).toList()
            if (matches.isEmpty()) {
                val t = raw.trim()
                if (t.isNotEmpty() && !t.startsWith("[")) plain += t
                continue
            }
            val body = raw.substring(matches.last().range.last + 1).trim()
            for (m in matches) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong()
                synced += LyricLine(min * 60_000 + sec * 1000 + ms, body)
            }
        }
        if (synced.isNotEmpty()) return Lyrics(synced.sortedBy { it.timeMs }, true)
        if (plain.isNotEmpty()) return Lyrics(plain.map { LyricLine(-1, it) }, false)
        return null
    }
}

class LyricsRepo(ctx: Context) {
    private val appCtx: Context = ctx.applicationContext
    val dir: File = File(ctx.filesDir, "lyrics").apply { mkdirs() }

    private fun lrc(t: Track) = File(dir, "${t.id}.lrc")

    fun hasLocal(t: Track) = lrc(t).exists()

    fun save(t: Track, text: String) {
        lrc(t).writeText(text)
    }

    fun delete(t: Track) {
        lrc(t).delete()
    }

    private fun sidecar(t: Track) = File(t.path.substringBeforeLast('.') + ".lrc")

    /** Which sources have lyrics for this song right now (online is always "maybe"). */
    suspend fun available(t: Track): Map<String, Boolean> = withContext(Dispatchers.IO) {
        mapOf(
            "saved" to lrc(t).exists(),
            "file" to try { sidecar(t).let { it.exists() && it.canRead() } } catch (_: Exception) { false },
            "embedded" to (TagIo.embeddedLyrics(appCtx, t) != null),
        )
    }

    private fun fromSource(t: Track, src: String, force: Boolean): Lyrics? = try {
        when (src) {
            "saved" -> lrc(t).takeIf { it.exists() }?.let { LrcParser.parse(it.readText()) }
            "file" -> sidecar(t).takeIf { it.exists() && it.canRead() }?.let { LrcParser.parse(it.readText()) }
            "embedded" -> TagIo.embeddedLyrics(appCtx, t)?.let { LrcParser.parse(it) }
            else -> null
        }
    } catch (_: Exception) {
        null
    }

    /** Tries the sources in [order] ("saved", "file", "embedded"); the first that has lyrics wins. */
    suspend fun load(t: Track, order: List<String>, allowOnline: Boolean, force: Boolean = false): Lyrics? =
        withContext(Dispatchers.IO) {
            for (src in order) {
                fromSource(t, src, force)?.let { return@withContext it }
            }
            null
        }

}
