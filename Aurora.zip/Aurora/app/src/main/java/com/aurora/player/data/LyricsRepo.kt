package com.aurora.player.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

object LrcParser {
    private val tag = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")

    fun parse(text: String): Lyrics? {
        val synced = ArrayList<LyricLine>()
        val plain = ArrayList<String>()
        for (raw in text.lines()) {
            val matches = tag.findAll(raw).toList()
            if (matches.isEmpty()) {
                val t = raw.trim()
                if (t.isNotEmpty() && !t.startsWith("[")) plain += t
                continue
            }
            val body = raw.substring(matches.last().range.last + 1).trim()
            for (m in matches) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3]
                val ms = if (frac.isEmpty()) 0L else frac.padEnd(3, '0').take(3).toLong()
                synced += LyricLine(min * 60_000 + sec * 1000 + ms, body)
            }
        }
        if (synced.isNotEmpty()) return Lyrics(synced.sortedBy { it.timeMs }, true)
        if (plain.isNotEmpty()) return Lyrics(plain.map { LyricLine(-1, it) }, false)
        return null
    }
}

class LyricsRepo(ctx: Context) {
    val dir: File = File(ctx.filesDir, "lyrics").apply { mkdirs() }

    private fun lrc(t: Track) = File(dir, "${t.id}.lrc")
    private fun miss(t: Track) = File(dir, "${t.id}.none")

    fun hasLocal(t: Track) = lrc(t).exists()

    fun save(t: Track, text: String) {
        lrc(t).writeText(text)
        miss(t).delete()
    }

    fun delete(t: Track) {
        lrc(t).delete()
    }

    /** Order: imported/downloaded copy -> .lrc next to the song -> (optional) LRCLIB. */
    suspend fun load(t: Track, allowOnline: Boolean, force: Boolean = false): Lyrics? =
        withContext(Dispatchers.IO) {
            val local = lrc(t)
            if (!force && local.exists()) {
                return@withContext LrcParser.parse(local.readText())
            }
            if (!force) {
                try {
                    val side = File(t.path.substringBeforeLast('.') + ".lrc")
                    if (side.exists() && side.canRead()) {
                        return@withContext LrcParser.parse(side.readText())
                    }
                } catch (_: Exception) {
                }
            }
            if (allowOnline && (force || !miss(t).exists())) {
                val text = fetchOnline(t)
                if (text != null) {
                    local.writeText(text)
                    return@withContext LrcParser.parse(text)
                } else {
                    miss(t).writeText(System.currentTimeMillis().toString())
                }
            }
            null
        }

    private fun http(url: String): String? = try {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "Aurora Player 1.0")
        try {
            if (c.responseCode == 200) c.inputStream.bufferedReader().readText() else null
        } finally {
            c.disconnect()
        }
    } catch (e: Exception) {
        null
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun pick(o: JSONObject): String? {
        val synced = o.optString("syncedLyrics", "")
        if (synced.isNotBlank() && synced != "null") return synced
        val plain = o.optString("plainLyrics", "")
        if (plain.isNotBlank() && plain != "null") return plain
        return null
    }

    private fun fetchOnline(t: Track): String? {
        val secs = t.durationMs / 1000
        val artist = if (t.artist.startsWith("Unknown")) "" else t.artist
        val exact = "https://lrclib.net/api/get?track_name=${enc(t.title)}&artist_name=${enc(artist)}" +
            "&album_name=${enc(t.album)}&duration=$secs"
        http(exact)?.let { body ->
            try {
                pick(JSONObject(body))?.let { return it }
            } catch (_: Exception) {
            }
        }
        val search = "https://lrclib.net/api/search?q=${enc("$artist ${t.title}".trim())}"
        http(search)?.let { body ->
            try {
                val arr = JSONArray(body)
                var best: JSONObject? = null
                var bestDiff = Double.MAX_VALUE
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i)
                    if (pick(o) == null) continue
                    val diff = Math.abs(o.optDouble("duration", 0.0) - secs)
                    if (diff < bestDiff) { bestDiff = diff; best = o }
                }
                if (best != null && bestDiff <= 6) return pick(best)
            } catch (_: Exception) {
            }
        }
        return null
    }
}
