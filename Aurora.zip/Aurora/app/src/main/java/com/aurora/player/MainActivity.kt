package com.aurora.player

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.aurora.player.backup.BackupManager
import com.aurora.player.backup.BackupScheduler
import com.aurora.player.backup.LoadedBackup
import com.aurora.player.backup.RestoreOptions
import com.aurora.player.data.MediaScanner
import com.aurora.player.data.PlaylistIo
import com.aurora.player.data.Track
import com.aurora.player.lyrics.LyricsOverlayService
import com.aurora.player.player.PlaybackService
import com.aurora.player.ui.Actions
import com.aurora.player.ui.AuroraRoot
import com.aurora.player.ui.AuroraTheme
import com.aurora.player.ui.LocalActions
import com.aurora.player.widget.WidgetUpdater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var pendingEdit: (() -> Unit)? = null
    private var pendingRoute by mutableStateOf<String?>(null)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { loadLibrary() }

    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                    )
                } catch (_: Exception) {
                }
                controller.store.update { it.copy(backupFolder = uri.toString()) }
                BackupScheduler.apply(this, controller.store.data)
                toast("Backups will be saved in that folder")
            }
        }

    private val backupPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { loadBackup(it, "Selected backup") } }

    private val backupSaver =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri -> uri?.let(::saveBackupTo) }

    private val plPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(::importPlaylistFile) }

    private var exportTracks: List<Track> = emptyList()
    private val plExport =
        registerForActivityResult(ActivityResultContracts.CreateDocument("audio/x-mpegurl")) { uri -> uri?.let(::writeM3u) }

    private val lrcPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(::readLrc) }

    private val writeRequest =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            if (r.resultCode == RESULT_OK) pendingEdit?.invoke()
            pendingEdit = null
        }

    private val overlayPermissionOnly =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    private val overlayPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) LyricsOverlayService.start(this)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pendingRoute = intent?.getStringExtra("route")
        startService(Intent(this, PlaybackService::class.java))
        requestPermissions()

        val actions = Actions(
            editTags = ::editTags,
            importLyrics = { lrcPicker.launch(arrayOf("*/*")) },
            importPlaylist = { plPicker.launch(arrayOf("*/*")) },
            exportPlaylist = { name, tracks ->
                exportTracks = tracks
                plExport.launch("$name.m3u")
            },
            toggleOverlay = ::toggleOverlay,
            rescan = ::loadLibrary,
            chooseBackupFolder = { folderPicker.launch(null) },
            backupNow = ::backupNow,
            openRestore = ::openRestore,
            browseBackup = { backupPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
            loadBackup = ::loadBackup,
            applyRestore = ::applyRestore,
            ensureOverlayPermission = ::ensureOverlayPermission,
        )
        setContent {
            AuroraTheme(controller.store.data.themeMode) {
                CompositionLocalProvider(LocalActions provides actions) {
                    AuroraRoot(controller, pendingRoute) { pendingRoute = null }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingRoute = intent.getStringExtra("route")
    }

    private fun requestPermissions() {
        val needed = buildList {
            if (Build.VERSION.SDK_INT >= 33) {
                add(Manifest.permission.READ_MEDIA_AUDIO)
                add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) loadLibrary() else permLauncher.launch(missing.toTypedArray())
    }

    private fun hasAudioPermission(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadLibrary() {
        if (!hasAudioPermission()) return
        lifecycleScope.launch {
            val list = withContext(Dispatchers.IO) { MediaScanner.scan(this@MainActivity) }
            controller.attachLibrary(list)
            WidgetUpdater.update(this@MainActivity)
            maybeAutoBackup()
        }
    }

    // ---- backup / restore ----

    /** Catch-up for when the background job was delayed (battery saver etc.). */
    private fun maybeAutoBackup() {
        val d = controller.store.data
        if (!d.autoBackup || d.backupFolder.isEmpty() || controller.library.isEmpty()) return
        if (System.currentTimeMillis() - d.lastBackupAt < d.autoBackupDays * 86_400_000L) return
        lifecycleScope.launch(Dispatchers.IO) { BackupManager.backupToFolder(this@MainActivity, controller) }
    }

    private fun backupNow() {
        if (controller.library.isEmpty()) { toast("No songs found yet"); return }
        if (controller.store.data.backupFolder.isEmpty()) {
            backupSaver.launch(BackupManager.newFileName())
            return
        }
        val ui = backupUi
        lifecycleScope.launch {
            ui.busy = true
            val ok = withContext(Dispatchers.IO) { BackupManager.backupToFolder(this@MainActivity, controller) }
            ui.busy = false
            toast(if (ok) "Backup created successfully" else "Couldn't write to the backup folder. Choose it again in Settings.")
        }
    }

    private fun saveBackupTo(uri: Uri) {
        val ui = backupUi
        lifecycleScope.launch {
            ui.busy = true
            val ok = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openOutputStream(uri)?.use { BackupManager.write(controller, it) }
                    controller.store.update { it.copy(lastBackupAt = System.currentTimeMillis()) }
                    true
                } catch (e: Exception) {
                    false
                }
            }
            ui.busy = false
            toast(if (ok) "Backup created successfully" else "Couldn't write the backup file")
        }
    }

    private fun openRestore() {
        val ui = backupUi
        lifecycleScope.launch {
            ui.files = withContext(Dispatchers.IO) { BackupManager.listBackups(this@MainActivity, controller.store.data.backupFolder) }
            ui.picker = true
        }
    }

    private fun loadBackup(uri: Uri, name: String) {
        val ui = backupUi
        lifecycleScope.launch {
            ui.busy = true
            val loaded = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.use { BackupManager.read(it) }
                } catch (e: Exception) {
                    null
                }
            }
            ui.busy = false
            if (loaded == null) {
                toast("That isn't an Aurora backup. (Musicolet's own backups are encrypted and can't be read by other apps.)")
                return@launch
            }
            ui.previewName = name
            ui.preview = loaded
        }
    }

    private fun applyRestore(b: LoadedBackup, opts: RestoreOptions) {
        val ui = backupUi
        lifecycleScope.launch {
            ui.busy = true
            val r = try {
                BackupManager.restore(controller, b, opts)
            } catch (e: Exception) {
                null
            }
            ui.busy = false
            WidgetUpdater.update(this@MainActivity)
            if (r == null) toast("Restore failed")
            else toast(
                "Restore completed: ${r.favourites} favourites, ${r.playlists} playlists, ${r.lyrics} lyrics" +
                    if (r.skippedSongs > 0) " (${r.skippedSongs} songs not found on this phone)" else ""
            )
        }
    }

    private fun importPlaylistFile(uri: Uri) {
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                } catch (e: Exception) {
                    null
                }
            }
            if (text.isNullOrBlank()) { toast("Couldn't read that file"); return@launch }
            val entries = PlaylistIo.parse(text)
            val ids = PlaylistIo.match(entries, controller.library)
            if (ids.isEmpty()) {
                toast("None of the ${entries.size} songs in that playlist were found on this phone")
                return@launch
            }
            var name = "Imported playlist"
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0).substringBeforeLast('.').ifBlank { name }
            }
            controller.store.createPlaylist(name, ids)
            toast("Imported ${ids.size} of ${entries.size} songs into “$name”")
        }
    }

    private fun writeM3u(uri: Uri) {
        val text = PlaylistIo.toM3u(exportTracks)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                    true
                } catch (e: Exception) {
                    false
                }
            }
            toast(if (ok) "Playlist exported" else "Couldn't write the file")
        }
    }

    private fun readLrc(uri: Uri) {
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                } catch (e: Exception) {
                    null
                }
            }
            if (text.isNullOrBlank()) toast("Couldn't read that file") else controller.importLyrics(text)
        }
    }

    /** Returns true if the overlay permission is already granted; otherwise sends the user to grant it. */
    private fun ensureOverlayPermission(): Boolean {
        if (Settings.canDrawOverlays(this)) return true
        toast("Allow “Display over other apps” for Aurora, then turn this on again")
        overlayPermissionOnly.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        return false
    }

    private fun toggleOverlay(on: Boolean) {
        if (!on) {
            LyricsOverlayService.stop(this)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow “Display over other apps” for Aurora, then come back")
            overlayPermission.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            LyricsOverlayService.start(this)
        }
    }

    /** Updates the MediaStore entry (what Android and this app display). The audio file bytes are untouched. */
    private fun editTags(t: Track, title: String, artist: String, album: String) {
        val uri = Uri.parse(t.uri)
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.TITLE, title)
            put(MediaStore.Audio.Media.ARTIST, artist)
            put(MediaStore.Audio.Media.ALBUM, album)
        }
        val doEdit: () -> Unit = {
            try {
                contentResolver.update(uri, values, null, null)
                loadLibrary()
            } catch (e: Exception) {
                toast("Couldn't update tags")
            }
        }
        when {
            Build.VERSION.SDK_INT >= 30 -> {
                pendingEdit = doEdit
                val pi = MediaStore.createWriteRequest(contentResolver, listOf(uri))
                writeRequest.launch(IntentSenderRequest.Builder(pi.intentSender).build())
            }
            Build.VERSION.SDK_INT == 29 -> {
                try {
                    contentResolver.update(uri, values, null, null)
                    loadLibrary()
                } catch (e: RecoverableSecurityException) {
                    pendingEdit = doEdit
                    writeRequest.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                } catch (e: Exception) {
                    toast("Couldn't update tags")
                }
            }
            else -> doEdit()
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
