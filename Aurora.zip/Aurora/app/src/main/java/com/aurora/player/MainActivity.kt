package com.aurora.player

import android.Manifest
import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Intent
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.aurora.player.backup.BackupManager
import com.aurora.player.backup.BackupScheduler
import com.aurora.player.backup.LoadedBackup
import com.aurora.player.backup.RestoreOptions
import com.aurora.player.data.MediaScanner
import com.aurora.player.data.PlaylistIo
import com.aurora.player.data.TagData
import com.aurora.player.data.TagIo
import java.io.File
import com.aurora.player.data.Track
import com.aurora.player.lyrics.LyricsOverlayService
import com.aurora.player.player.PlaybackService
import com.aurora.player.ui.Actions
import com.aurora.player.ui.AuroraRoot
import com.aurora.player.ui.AuroraTheme
import com.aurora.player.ui.LocalActions
import com.aurora.player.widget.WidgetUpdater
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    private var pendingEdit: (() -> Unit)? = null
    private var startedOnce = false
    private var pendingRoute by mutableStateOf<String?>(null)

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { loadLibrary() }

    private val folderPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
                    )
                } catch (_: Exception) {
                }
                controller.store.update { it.copy(backupFolder = uri.toString()) }
                BackupScheduler.apply(this, controller.store.data)
                toast("Backups will be saved in that folder")
            }
        }

    private val backupPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { loadBackup(it, "Selected backup") } }

    private val backupSaver =
        registerForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri -> uri?.let(::saveBackupTo) }

    private val plPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(::importPlaylistFile) }

    private var exportTracks: List<Track> = emptyList()
    private val plExport =
        registerForActivityResult(ActivityResultContracts.CreateDocument("audio/x-mpegurl")) { uri -> uri?.let(::writeM3u) }

    private val bgPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
                } catch (_: Exception) {
                }
                controller.store.update { it.copy(customBgUri = uri.toString(), nowBg = 5) }
            }
        }


    private val lrcPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let(::readLrc) }

    private val writeRequest =
        registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
            if (r.resultCode == RESULT_OK) pendingEdit?.invoke()
            pendingEdit = null
        }

    private val overlayPermissionOnly =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { }

    private val overlayPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            if (Settings.canDrawOverlays(this)) LyricsOverlayService.start(this)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        pendingRoute = intent?.getStringExtra("route")
        startService(Intent(this, PlaybackService::class.java))
        requestPermissions()

        val actions = Actions(
            editTags = ::editTags,
            importLyrics = { lrcPicker.launch(arrayOf("*/*")) },
            importPlaylist = { plPicker.launch(arrayOf("*/*")) },
            exportPlaylist = { name, tracks ->
                exportTracks = tracks
                plExport.launch("$name.m3u")
            },
            toggleOverlay = ::toggleOverlay,
            rescan = ::loadLibrary,
            chooseBackupFolder = { folderPicker.launch(null) },
            backupNow = ::backupNow,
            openRestore = ::openRestore,
            browseBackup = { backupPicker.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) },
            loadBackup = ::loadBackup,
            applyRestore = ::applyRestore,
            ensureOverlayPermission = ::ensureOverlayPermission,
            pickBackground = { bgPicker.launch(arrayOf("image/*")) },
            saveText = { name, mime, content ->
                pendingText = content
                if (mime.contains("csv")) csvSaver.launch(name) else m3u8Saver.launch(name)
            },
            saveArt = ::saveArtToGallery,
            deleteTracks = ::deleteTracks,
            copyTracks = { list -> pendingCopy = list; copyFolderPicker.launch(null) },
        )
        setContent {
            AuroraTheme(controller.store.data.themeMode, controller.store.data.accentColor) {
                CompositionLocalProvider(LocalActions provides actions) {
                    AuroraRoot(controller, pendingRoute) { pendingRoute = null }
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingRoute = intent.getStringExtra("route")
    }

    private fun requestPermissions() {
        val needed = buildList {
            if (Build.VERSION.SDK_INT >= 33) {
                add(Manifest.permission.READ_MEDIA_AUDIO)
                add(Manifest.permission.POST_NOTIFICATIONS)
            } else {
                add(Manifest.permission.READ_EXTERNAL_STORAGE)
            }
        }
        val missing = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (missing.isEmpty()) loadLibrary() else permLauncher.launch(missing.toTypedArray())
    }

    private fun hasAudioPermission(): Boolean {
        val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        return ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED
    }

    private fun loadLibrary() {
        if (!hasAudioPermission()) return
        lifecycleScope.launch {
            val d = controller.store.data
            val all = withContext(Dispatchers.IO) { MediaScanner.scan(this@MainActivity, d.minDurationSec) }
            controller.allFolders = (all.map { it.folder } + d.excludedFolders).distinct().sortedBy { it.lowercase() }
            var list = if (d.excludedFolders.isEmpty()) all else all.filter { it.folder !in d.excludedFolders }
            if (d.showFileNames) list = list.map { it.copy(title = it.path.substringAfterLast('/').substringBeforeLast('.')) }
            com.aurora.player.ui.ArtLoader.enabled = d.loadArt
            controller.attachLibrary(list)
            if (d.autoPlayOnStart && !startedOnce && list.isNotEmpty()) { startedOnce = true; controller.play() }
            WidgetUpdater.update(this@MainActivity)
            maybeAutoBackup()
        }
    }

    // ---- backup / restore ----

    /** Catch-up for when the background job was delayed (battery saver etc.). */
    private fun maybeAutoBackup() {
        val d = controller.store.data
        if (!d.autoBackup || d.backupFolder.isEmpty() || controller.library.isEmpty()) return
        if (System.currentTimeMillis() - d.lastBackupAt < d.autoBackupDays * 86_400_000L) return
        lifecycleScope.launch(Dispatchers.IO) { BackupManager.backupToFolder(this@MainActivity, controller) }
    }

    private fun backupNow() {
        if (controller.library.isEmpty()) { toast("No songs found yet"); return }
        if (controller.store.data.backupFolder.isEmpty()) {
            backupSaver.launch(BackupManager.newFileName())
            return
        }
        val ui = backupUi
        lifecycleScope.launch {
            ui.busy = true
            val ok = withContext(Dispatchers.IO) { BackupManager.backupToFolder(this@MainActivity, controller) }
            ui.busy = false
            toast(if (ok) "Backup created successfully" else "Couldn't write to the backup folder. Choose it again in Settings.")
        }
    }

    private fun saveBackupTo(uri: Uri) {
        val ui = backupUi
        lifecycleScope.launch {
            ui.busy = true
            val ok = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openOutputStream(uri)?.use { BackupManager.write(controller, it) }
                    controller.store.update { it.copy(lastBackupAt = System.currentTimeMillis()) }
                    true
                } catch (e: Exception) {
                    false
                }
            }
            ui.busy = false
            toast(if (ok) "Backup created successfully" else "Couldn't write the backup file")
        }
    }

    private fun openRestore() {
        val ui = backupUi
        lifecycleScope.launch {
            ui.files = withContext(Dispatchers.IO) { BackupManager.listBackups(this@MainActivity, controller.store.data.backupFolder) }
            ui.picker = true
        }
    }

    private fun loadBackup(uri: Uri, name: String) {
        val ui = backupUi
        lifecycleScope.launch {
            ui.busy = true
            val loaded = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.use { BackupManager.read(it) }
                } catch (e: Exception) {
                    null
                }
            }
            ui.busy = false
            if (loaded == null) {
                toast("That isn't an Aurora backup. (Musicolet's own backups are encrypted and can't be read by other apps.)")
                return@launch
            }
            ui.previewName = name
            ui.preview = loaded
        }
    }

    private fun applyRestore(b: LoadedBackup, opts: RestoreOptions) {
        val ui = backupUi
        lifecycleScope.launch {
            ui.busy = true
            val r = try {
                BackupManager.restore(controller, b, opts)
            } catch (e: Exception) {
                null
            }
            ui.busy = false
            WidgetUpdater.update(this@MainActivity)
            if (r == null) toast("Restore failed")
            else toast(
                "Restore completed: ${r.favourites} favourites, ${r.playlists} playlists, ${r.lyrics} lyrics" +
                    if (r.skippedSongs > 0) " (${r.skippedSongs} songs not found on this phone)" else ""
            )
        }
    }

    private fun importPlaylistFile(uri: Uri) {
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                } catch (e: Exception) {
                    null
                }
            }
            if (text.isNullOrBlank()) { toast("Couldn't read that file"); return@launch }
            val entries = PlaylistIo.parse(text)
            val ids = PlaylistIo.match(entries, controller.library)
            if (ids.isEmpty()) {
                toast("None of the ${entries.size} songs in that playlist were found on this phone")
                return@launch
            }
            var name = "Imported playlist"
            contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0).substringBeforeLast('.').ifBlank { name }
            }
            controller.store.createPlaylist(name, ids)
            toast("Imported ${ids.size} of ${entries.size} songs into “$name”")
        }
    }

    private fun writeM3u(uri: Uri) {
        val text = PlaylistIo.toM3u(exportTracks)
        lifecycleScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openOutputStream(uri)?.use { it.write(text.toByteArray(Charsets.UTF_8)) }
                    true
                } catch (e: Exception) {
                    false
                }
            }
            toast(if (ok) "Playlist exported" else "Couldn't write the file")
        }
    }

    private fun readLrc(uri: Uri) {
        lifecycleScope.launch {
            val text = withContext(Dispatchers.IO) {
                try {
                    contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }
                } catch (e: Exception) {
                    null
                }
            }
            if (text.isNullOrBlank()) toast("Couldn't read that file") else controller.importLyrics(text)
        }
    }

    /** Returns true if the overlay permission is already granted; otherwise sends the user to grant it. */
    private fun ensureOverlayPermission(): Boolean {
        if (Settings.canDrawOverlays(this)) return true
        toast("Allow “Display over other apps” for Aurora, then turn this on again")
        overlayPermissionOnly.launch(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        return false
    }

    private fun toggleOverlay(on: Boolean) {
        if (!on) {
            LyricsOverlayService.stop(this)
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Allow “Display over other apps” for Aurora, then come back")
            overlayPermission.launch(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        } else {
            LyricsOverlayService.start(this)
        }
    }

    /**
     * Writes the tags into the audio file itself (via a temporary copy, so a failure can't corrupt the song),
     * then updates the Android media library entry so the change shows everywhere.
     */
    private fun editTags(t: Track, d: TagData) {
        val uri = Uri.parse(t.uri)
        val work: () -> Unit = {
            lifecycleScope.launch {
                val result: Any = withContext(Dispatchers.IO) {
                    try {
                        val tmp = File(cacheDir, "tag_edit." + t.path.substringAfterLast('.', "mp3"))
                        contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                        TagIo.write(tmp, d)
                        if (tmp.length() <= 0L) throw IllegalStateException("empty")
                        contentResolver.openOutputStream(uri, "wt")!!.use { o -> tmp.inputStream().use { i -> i.copyTo(o) } }
                        tmp.delete()
                        "file"
                    } catch (e: RecoverableSecurityException) {
                        e
                    } catch (e: SecurityException) {
                        "denied"
                    } catch (e: Throwable) {
                        "unsupported"
                    }
                }
                if (result is RecoverableSecurityException) {
                    pendingEdit = { editTags(t, d) }
                    writeRequest.launch(IntentSenderRequest.Builder(result.userAction.actionIntent.intentSender).build())
                    return@launch
                }
                if (result == "denied") { toast("Permission to edit this file was denied"); return@launch }
                // keep the media library in step (title/artist/album/year/track)
                withContext(Dispatchers.IO) {
                    try {
                        val v = ContentValues().apply {
                            put(MediaStore.Audio.Media.TITLE, d.title)
                            put(MediaStore.Audio.Media.ARTIST, d.artist)
                            put(MediaStore.Audio.Media.ALBUM, d.album)
                            d.year.toIntOrNull()?.let { put(MediaStore.Audio.Media.YEAR, it) }
                            d.track.substringBefore('/').toIntOrNull()?.let { put(MediaStore.Audio.Media.TRACK, it) }
                        }
                        contentResolver.update(uri, v, null, null)
                        if (t.path.isNotEmpty()) MediaScannerConnection.scanFile(this@MainActivity, arrayOf(t.path), null, null)
                    } catch (_: Exception) {
                    }
                }
                toast(if (result == "file") "Tags saved in the file" else "This file type can't hold tags. Saved in the library only.")
                loadLibrary()
            }
        }
        if (Build.VERSION.SDK_INT >= 30) {
            pendingEdit = work
            val pi = MediaStore.createWriteRequest(contentResolver, listOf(uri))
            writeRequest.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            work()
        }
    }


    // ---- save text (queue .csv / .m3u8) ----
    private var pendingText: String? = null
    private val csvSaver = registerForActivityResult(ActivityResultContracts.CreateDocument("text/csv")) { uri -> writeText(uri) }
    private val m3u8Saver = registerForActivityResult(ActivityResultContracts.CreateDocument("audio/x-mpegurl")) { uri -> writeText(uri) }

    private fun writeText(uri: Uri?) {
        val text = pendingText
        pendingText = null
        if (uri == null || text == null) return
        try {
            contentResolver.openOutputStream(uri, "wt")!!.use { it.write(text.toByteArray(Charsets.UTF_8)) }
            toast("Saved")
        } catch (e: Exception) {
            toast("Couldn't save the file")
        }
    }

    // ---- copy songs to a folder ----
    private var pendingCopy: List<Track> = emptyList()
    private val copyFolderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        val list = pendingCopy
        pendingCopy = emptyList()
        if (uri == null || list.isEmpty()) return@registerForActivityResult
        lifecycleScope.launch {
            val n = withContext(Dispatchers.IO) {
                val dir = androidx.documentfile.provider.DocumentFile.fromTreeUri(this@MainActivity, uri) ?: return@withContext 0
                var done = 0
                for (t in list) {
                    try {
                        val src = Uri.parse(t.uri)
                        val mime = contentResolver.getType(src) ?: "audio/mpeg"
                        val base = t.path.substringAfterLast('/').substringBeforeLast('.').ifEmpty { t.title }
                        val out = dir.createFile(mime, base) ?: continue
                        contentResolver.openInputStream(src)!!.use { i ->
                            contentResolver.openOutputStream(out.uri)!!.use { o -> i.copyTo(o) }
                        }
                        done++
                    } catch (_: Exception) {
                    }
                }
                done
            }
            toast("Copied $n of ${list.size} songs")
        }
    }

    // ---- delete songs from the device ----
    private var pendingDelete: List<Uri> = emptyList()
    private val deleteRequest = registerForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        if (Build.VERSION.SDK_INT >= 30) {
            if (r.resultCode == RESULT_OK) { toast("Deleted"); loadLibrary() }
        } else if (r.resultCode == RESULT_OK) {
            deleteNext()
        }
    }

    private fun deleteTracks(list: List<Track>) {
        val uris = list.map { Uri.parse(it.uri) }
        if (uris.isEmpty()) return
        if (Build.VERSION.SDK_INT >= 30) {
            val pi = MediaStore.createDeleteRequest(contentResolver, uris)
            deleteRequest.launch(IntentSenderRequest.Builder(pi.intentSender).build())
        } else {
            pendingDelete = uris
            deleteNext()
        }
    }

    /** Android 10: delete one by one; Android asks for permission per file when needed. */
    private fun deleteNext() {
        while (pendingDelete.isNotEmpty()) {
            val u = pendingDelete.first()
            try {
                contentResolver.delete(u, null, null)
                pendingDelete = pendingDelete.drop(1)
            } catch (e: RecoverableSecurityException) {
                deleteRequest.launch(IntentSenderRequest.Builder(e.userAction.actionIntent.intentSender).build())
                return
            } catch (e: Exception) {
                pendingDelete = pendingDelete.drop(1)
            }
        }
        toast("Deleted")
        loadLibrary()
    }

    // ---- save album art to the gallery ----
    private fun saveArtToGallery(t: Track) {
        lifecycleScope.launch {
            val bmp = com.aurora.player.ui.ArtLoader.load(this@MainActivity, t)
            if (bmp == null) { toast("This song has no album art"); return@launch }
            val ok = withContext(Dispatchers.IO) {
                try {
                    val v = ContentValues().apply {
                        put(MediaStore.Images.Media.DISPLAY_NAME, "${t.album.ifBlank { t.title }}.jpg".replace('/', '_'))
                        put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                        put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Aurora")
                        put(MediaStore.Images.Media.IS_PENDING, 1)
                    }
                    val uri = contentResolver.insert(MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY), v)!!
                    contentResolver.openOutputStream(uri)!!.use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 95, it) }
                    v.clear(); v.put(MediaStore.Images.Media.IS_PENDING, 0)
                    contentResolver.update(uri, v, null, null)
                    true
                } catch (e: Exception) {
                    false
                }
            }
            toast(if (ok) "Album art saved to Pictures/Aurora" else "Couldn't save the picture")
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
