package com.aurora.player.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.QueueMusic
import androidx.compose.material.icons.rounded.Bedtime
import androidx.compose.material.icons.rounded.Equalizer
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.FavoriteBorder
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Lyrics
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Repeat
import androidx.compose.material.icons.rounded.RepeatOne
import androidx.compose.material.icons.rounded.Shuffle
import androidx.compose.material.icons.rounded.SkipNext
import androidx.compose.material.icons.rounded.SkipPrevious
import androidx.compose.material.icons.rounded.Subtitles
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.withFrameNanos
import androidx.media3.common.Player
import com.aurora.player.data.formatTime
import com.aurora.player.data.indexAt
import com.aurora.player.player.PlayerController
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.roundToInt

@Composable
fun NowPlayingScreen(c: PlayerController, onClose: () -> Unit, openQueue: () -> Unit, openEq: () -> Unit) {
    val track = c.current
    val bmp = rememberArt(track)
    val surface = MaterialTheme.colorScheme.background
    val accent by animateColorAsState(
        bmp?.dominantColor() ?: MaterialTheme.colorScheme.primary, tween(800), label = "accent",
    )
    var showLyrics by remember { mutableStateOf(false) }
    var sleepDialog by remember { mutableStateOf(false) }
    val actions = LocalActions.current

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(accent.copy(alpha = 0.6f), surface, surface)))
    ) {
        Column(
            Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
        ) {
            // top bar
            Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(44.dp).bounceClick(onClose), contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.KeyboardArrowDown, null, modifier = Modifier.size(30.dp))
                }
                Text(
                    "Now playing", Modifier.weight(1f), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Box(Modifier.size(44.dp).bounceClick(openQueue), contentAlignment = Alignment.Center) {
                    Icon(Icons.AutoMirrored.Rounded.QueueMusic, null)
                }
            }

            // art / lyrics
            Box(Modifier.weight(1f).fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) {
                Crossfade(showLyrics, animationSpec = tween(400), label = "artOrLyrics") { lyr ->
                    if (lyr) LyricsPane(c) else ArtPane(c, accent)
                }
            }

            // title
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                AnimatedContent(
                    track?.id, Modifier.weight(1f),
                    transitionSpec = {
                        (slideInVertically(tween(350)) { it / 2 } + fadeIn(tween(350))) togetherWith
                            (slideOutVertically(tween(250)) { -it / 2 } + fadeOut(tween(200)))
                    },
                    label = "title",
                ) {
                    Column {
                        Text(
                            track?.title ?: "Nothing playing", maxLines = 1, overflow = TextOverflow.Ellipsis,
                            style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold,
                        )
                        Text(
                            track?.let { "${it.artist} — ${it.album}" } ?: "Pick a song from your library",
                            maxLines = 1, overflow = TextOverflow.Ellipsis, color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                }
                if (track != null) {
                    val fav = c.store.isFavourite(track.id)
                    Box(Modifier.size(48.dp).bounceClick { c.store.toggleFavourite(track.id) }, contentAlignment = Alignment.Center) {
                        AnimatedContent(
                            fav,
                            transitionSpec = { (scaleIn(spring(Spring.DampingRatioHighBouncy)) + fadeIn()) togetherWith (scaleOut() + fadeOut()) },
                            label = "fav",
                        ) { f ->
                            Icon(
                                if (f) Icons.Rounded.Favorite else Icons.Rounded.FavoriteBorder, null,
                                tint = if (f) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(28.dp),
                            )
                        }
                    }
                }
            }

            // seek bar
            var drag by remember { mutableStateOf<Float?>(null) }
            val dur = c.durationMs.coerceAtLeast(1L).toFloat()
            Slider(
                value = (drag ?: c.positionMs.toFloat()).coerceIn(0f, dur),
                onValueChange = { drag = it },
                onValueChangeFinished = { drag?.let { c.seekTo(it.toLong()) }; drag = null },
                valueRange = 0f..dur,
            )
            Row(Modifier.fillMaxWidth()) {
                Text(formatTime((drag ?: c.positionMs.toFloat()).toLong()), style = MaterialTheme.typography.labelMedium)
                if (c.abA >= 0) {
                    Text(
                        if (c.abB >= 0) "A–B  ${formatTime(c.abA)} – ${formatTime(c.abB)}" else "A  ${formatTime(c.abA)}",
                        Modifier.weight(1f), textAlign = TextAlign.Center, style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary,
                    )
                } else Spacer(Modifier.weight(1f))
                Text(formatTime(c.durationMs), style = MaterialTheme.typography.labelMedium)
            }

            // transport
            Row(
                Modifier.fillMaxWidth().padding(vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
            ) {
                ToggleIcon(Icons.Rounded.Shuffle, c.shuffle) { c.toggleShuffle() }
                Box(Modifier.size(52.dp).bounceClick { c.previous() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.SkipPrevious, null, modifier = Modifier.size(38.dp))
                }
                val pulse by animateFloatAsState(if (c.isPlaying) 1f else 0.94f, spring(Spring.DampingRatioMediumBouncy), label = "playScale")
                Box(
                    Modifier.size(76.dp).scale(pulse).clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary).bounceClick { c.togglePlay() },
                    contentAlignment = Alignment.Center,
                ) {
                    AnimatedContent(
                        c.isPlaying,
                        transitionSpec = { (scaleIn(spring(Spring.DampingRatioMediumBouncy)) + fadeIn()) togetherWith (scaleOut() + fadeOut()) },
                        label = "playPause",
                    ) { playing ->
                        Icon(
                            if (playing) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null,
                            tint = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(42.dp),
                        )
                    }
                }
                Box(Modifier.size(52.dp).bounceClick { c.next() }, contentAlignment = Alignment.Center) {
                    Icon(Icons.Rounded.SkipNext, null, modifier = Modifier.size(38.dp))
                }
                ToggleIcon(
                    if (c.repeatMode == Player.REPEAT_MODE_ONE) Icons.Rounded.RepeatOne else Icons.Rounded.Repeat,
                    c.repeatMode != Player.REPEAT_MODE_OFF,
                ) { c.cycleRepeat() }
            }

            // secondary row
            Row(
                Modifier.fillMaxWidth().padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically,
            ) {
                ToggleIcon(Icons.Rounded.Lyrics, showLyrics) { showLyrics = !showLyrics }
                ToggleIcon(Icons.Rounded.Subtitles, c.overlayActive) { actions.toggleOverlay(!c.overlayActive) }
                TextToggle("A–B", c.abA >= 0) { c.markAB() }
                TextToggle("${"%.2f".format(c.speed).trimEnd('0').trimEnd('.')}x", c.speed != 1f) {
                    val steps = listOf(0.75f, 1f, 1.25f, 1.5f, 2f)
                    val i = steps.indexOfFirst { it > c.speed + 0.001f }
                    c.setSpeedPitch(if (i < 0) steps.first() else steps[i], c.pitch)
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    ToggleIcon(Icons.Rounded.Bedtime, c.sleepLeftMs > 0 || c.sleepAfterTrack) { sleepDialog = true }
                    if (c.sleepLeftMs > 0) Text(formatTime(c.sleepLeftMs), style = MaterialTheme.typography.labelSmall)
                }
                ToggleIcon(Icons.Rounded.Equalizer, false, openEq)
            }
        }
    }

    if (sleepDialog) {
        AlertDialog(
            onDismissRequest = { sleepDialog = false },
            title = { Text("Sleep timer") },
            text = {
                Column {
                    listOf(15, 30, 45, 60, 90).forEach { m ->
                        TextButton({ c.setSleepMinutes(m); sleepDialog = false }, Modifier.fillMaxWidth()) { Text("$m minutes") }
                    }
                    TextButton({ c.setSleepEndOfTrack(); sleepDialog = false }, Modifier.fillMaxWidth()) { Text("End of this song") }
                    if (c.sleepLeftMs > 0 || c.sleepAfterTrack) {
                        TextButton({ c.cancelSleep(); sleepDialog = false }, Modifier.fillMaxWidth()) { Text("Cancel timer") }
                    }
                }
            },
            confirmButton = { TextButton({ sleepDialog = false }) { Text("Close") } },
        )
    }
}

@Composable
private fun ToggleIcon(icon: androidx.compose.ui.graphics.vector.ImageVector, on: Boolean, onClick: () -> Unit) {
    val tint by animateColorAsState(
        if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, tween(250), label = "tg",
    )
    Box(Modifier.size(44.dp).bounceClick(onClick), contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun TextToggle(label: String, on: Boolean, onClick: () -> Unit) {
    val tint by animateColorAsState(
        if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant, tween(250), label = "tt",
    )
    Box(Modifier.size(width = 48.dp, height = 44.dp).bounceClick(onClick), contentAlignment = Alignment.Center) {
        Text(label, color = tint, fontWeight = FontWeight.Bold, fontSize = 14.sp)
    }
}

// -------------------------------------------------------------------------------------------------
// Album art: spinning vinyl disc (or breathing square), swipe left/right to change song
// -------------------------------------------------------------------------------------------------

@Composable
private fun ArtPane(c: PlayerController, accent: Color) {
    val scope = rememberCoroutineScope()
    val offset = remember { Animatable(0f) }
    var angle by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(c.isPlaying) {
        if (c.isPlaying) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                angle = (angle + (now - last) / 1_000_000_000f * 24f) % 360f
                last = now
            }
        }
    }
    val glow = rememberInfiniteTransition(label = "glow")
    val pulse by glow.animateFloat(
        0.9f, 1.08f, infiniteRepeatable(tween(1800), RepeatMode.Reverse), label = "pulse",
    )
    val intensity by animateFloatAsState(if (c.isPlaying) 1f else 0f, tween(600), label = "glowI")
    val disc = c.store.data.discArt

    Box(
        Modifier.fillMaxSize()
            .offset { IntOffset(offset.value.roundToInt(), 0) }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragEnd = {
                        scope.launch {
                            if (offset.value < -160f) c.next() else if (offset.value > 160f) c.previous()
                            offset.animateTo(0f, spring(Spring.DampingRatioMediumBouncy))
                        }
                    },
                    onDragCancel = { scope.launch { offset.animateTo(0f) } },
                ) { change, dx ->
                    change.consume()
                    scope.launch { offset.snapTo(offset.value + dx) }
                }
            },
        contentAlignment = Alignment.Center,
    ) {
        AnimatedContent(
            c.current?.id,
            transitionSpec = {
                (scaleIn(tween(450), 0.8f) + fadeIn(tween(450))) togetherWith (scaleOut(tween(300), 0.8f) + fadeOut(tween(250)))
            },
            label = "artSwap",
        ) {
            if (disc) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    // pulsing glow
                    Box(
                        Modifier.fillMaxWidth(0.92f).aspectSquare().scale(pulse)
                            .background(
                                Brush.radialGradient(listOf(accent.copy(alpha = 0.45f * intensity), Color.Transparent)),
                                CircleShape,
                            )
                    )
                    Box(Modifier.fillMaxWidth(0.86f).aspectSquare().rotate(angle), contentAlignment = Alignment.Center) {
                        Canvas(Modifier.fillMaxSize()) {
                            drawCircle(Color(0xFF0B0B10))
                            val r = size.minDimension / 2
                            var rr = r * 0.97f
                            while (rr > r * 0.66f) {
                                drawCircle(Color.White.copy(alpha = 0.05f), rr, style = Stroke(1.2f))
                                rr -= r * 0.035f
                            }
                        }
                        AlbumArt(c.current, Modifier.fillMaxWidth(0.62f).aspectSquare(), CircleShape, 56.dp)
                        Box(Modifier.size(16.dp).background(Color(0xFF0B0B10), CircleShape))
                    }
                }
            } else {
                val s by animateFloatAsState(if (c.isPlaying) 1f else 0.86f, spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessLow), label = "sq")
                Box(
                    Modifier.fillMaxWidth(0.9f).aspectSquare().scale(s)
                        .graphicsLayer { shadowElevation = 40f; shape = RoundedCornerShape(28.dp); clip = true },
                ) {
                    AlbumArt(c.current, Modifier.fillMaxSize(), RoundedCornerShape(28.dp), 72.dp)
                }
            }
        }
    }
}

private fun Modifier.aspectSquare(): Modifier = this.aspectRatio(1f)

// -------------------------------------------------------------------------------------------------
// Lyrics view with animated scrolling + highlighted line
// -------------------------------------------------------------------------------------------------

@Composable
private fun LyricsPane(c: PlayerController) {
    val lyr = c.lyrics
    val actions = LocalActions.current
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("Fetch", Icons.Rounded.Lyrics, false) { c.refetchLyrics() }
            PillButton("Import .lrc", Icons.Rounded.Subtitles, false) { actions.importLyrics() }
        }
        when {
            c.lyricsLoading -> CenterNote("Looking for lyrics…")
            lyr == null -> CenterNote("No lyrics found.\nTap Fetch (needs internet once) or import an .lrc file.\nSaved lyrics work offline.")
            lyr.synced -> {
                val state = rememberLazyListState()
                val idx = lyr.indexAt(c.positionMs)
                LaunchedEffect(idx) {
                    if (idx >= 0) state.animateScrollToItem(max(0, idx), -(state.layoutInfo.viewportSize.height / 3))
                }
                LazyColumn(state = state, modifier = Modifier.fillMaxSize(), contentPadding = androidx.compose.foundation.layout.PaddingValues(vertical = 120.dp)) {
                    itemsIndexed(lyr.lines) { i, line ->
                        val active = i == idx
                        val sc by animateFloatAsState(if (active) 1f else 0.82f, spring(stiffness = Spring.StiffnessLow), label = "ls")
                        val col by animateColorAsState(
                            if (active) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f),
                            tween(300), label = "lc",
                        )
                        Text(
                            line.text.ifBlank { "♪" }, color = col, fontSize = 26.sp, fontWeight = FontWeight.Bold, lineHeight = 32.sp,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                                .graphicsLayer { scaleX = sc; scaleY = sc; transformOrigin = TransformOrigin(0f, 0.5f) }
                                .clip(RoundedCornerShape(8.dp))
                                .then(Modifier.bounceClick { c.seekTo(line.timeMs) }),
                        )
                    }
                }
            }
            else -> LazyColumn(Modifier.fillMaxSize()) {
                itemsIndexed(lyr.lines) { _, line ->
                    Text(line.text, fontSize = 18.sp, modifier = Modifier.padding(vertical = 4.dp))
                }
            }
        }
    }
}

@Composable
private fun CenterNote(text: String) {
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
