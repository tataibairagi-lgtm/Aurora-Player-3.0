package com.aurora.player.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.PlaylistAdd
import androidx.compose.material.icons.automirrored.rounded.Sort
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DragHandle
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.MoreHoriz
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Save
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.Timer
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import com.aurora.player.data.Track
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController

private fun csvCell(s: String) = "\"" + s.replace("\"", "\"\"") + "\""

fun queueCsv(tracks: List<Track>): String = buildString {
    append("Position,Title,Artist,Album,Duration (s),Path\n")
    tracks.forEachIndexed { i, t ->
        append("${i + 1},${csvCell(t.title)},${csvCell(t.artist)},${csvCell(t.album)},${t.durationMs / 1000},${csvCell(t.path)}\n")
    }
}

fun queueM3u8(tracks: List<Track>): String = buildString {
    append("#EXTM3U\n")
    tracks.forEach { t -> append("#EXTINF:${t.durationMs / 1000},${t.artist} - ${t.title}\n${t.path}\n") }
}

/** Musicolet-style queues page: up to 20 queues, drag to reorder, multi-select with options, search, export. */
@Composable
fun QueueScreen(c: PlayerController, back: () -> Unit, embedded: Boolean = false) {
    val actions = LocalActions.current
    val state = rememberLazyListState()
    val sel = remember { mutableStateListOf<Int>() }
    var query by remember { mutableStateOf("") }
    var queueMenu by remember { mutableStateOf(false) }
    var sortMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }
    var saveDialog by remember { mutableStateOf(false) }
    var newDialog by remember { mutableStateOf(false) }
    var renameDialog by remember { mutableStateOf(false) }
    var deleteDialog by remember { mutableStateOf(false) }
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragDy by remember { mutableFloatStateOf(0f) }
    val d = c.store.data
    val qName = d.queues.getOrNull(c.activeQueue)?.name ?: "Queue"

    BackHandler(enabled = sel.isNotEmpty()) { sel.clear() }
    LaunchedEffect(c.activeQueue) {
        sel.clear()
        if (c.currentIndex > 0) state.scrollToItem(c.currentIndex)
    }

    // stable keys so a row keeps its identity while it is dragged to a new position
    val keys = remember(c.queue) {
        val seen = HashMap<Long, Int>()
        c.queue.map { t -> val n = (seen[t.id] ?: 0) + 1; seen[t.id] = n; if (n == 1) "${t.id}" else "${t.id}#$n" }
    }
    val shown = remember(c.queue, query) {
        c.queue.withIndex().filter { (_, t) ->
            query.isBlank() || t.title.contains(query, true) || t.artist.contains(query, true) || t.album.contains(query, true)
        }.map { it.index }
    }
    fun toggle(i: Int) { if (i in sel) sel.remove(i) else sel.add(i) }

    Column(Modifier.fillMaxSize().then(if (embedded) Modifier else Modifier.statusBarsPadding())) {
        // ---- queue picker ----
        Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (!embedded) Box(Modifier.size(44.dp).bounceClick(back), contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Box(Modifier.weight(1f)) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .clickable { queueMenu = true }.padding(horizontal = 14.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(qName, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis, fontWeight = FontWeight.SemiBold)
                    Icon(Icons.Rounded.KeyboardArrowDown, null)
                }
                DropdownMenu(queueMenu, { queueMenu = false }) {
                    d.queues.forEachIndexed { i, q ->
                        DropdownMenuItem(
                            text = { Text("${q.name}  (${if (i == c.activeQueue) c.queue.size else q.trackIds.size})", fontWeight = if (i == c.activeQueue) FontWeight.Bold else FontWeight.Normal) },
                            onClick = { queueMenu = false; c.switchQueue(i) },
                        )
                    }
                    DropdownMenuItem(
                        text = { Text(if (d.queues.size >= c.maxQueues) "New queue (limit ${c.maxQueues} reached)" else "New queue…") },
                        enabled = d.queues.size < c.maxQueues,
                        onClick = { queueMenu = false; newDialog = true },
                    )
                    DropdownMenuItem(text = { Text("Rename this queue…") }, onClick = { queueMenu = false; renameDialog = true })
                }
            }
            Box(Modifier.size(44.dp).bounceClick { deleteDialog = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Close, null) }
        }

        // ---- controls ----
        Row(Modifier.padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(48.dp).bounceClick { c.togglePlay() }, contentAlignment = Alignment.Center) {
                Icon(if (c.isPlaying) Icons.Rounded.Pause else Icons.Rounded.PlayArrow, null)
            }
            Box {
                Box(Modifier.size(48.dp).bounceClick { sortMenu = true }, contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.Sort, null) }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    listOf<Pair<String, (List<Track>) -> List<Track>>>(
                        "Sort by title" to { l -> l.sortedBy { it.title.lowercase() } },
                        "Sort by artist" to { l -> l.sortedBy { it.artist.lowercase() } },
                        "Sort by album" to { l -> l.sortedWith(compareBy({ it.album.lowercase() }, { it.trackNo })) },
                        "Sort by duration" to { l -> l.sortedBy { it.durationMs } },
                        "Sort by date added" to { l -> l.sortedByDescending { it.dateAdded } },
                        "Reverse order" to { l -> l.reversed() },
                        "Randomize" to { l -> l.shuffled() },
                    ).forEach { (label, f) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { sortMenu = false; c.reorderQueue(f(c.queue)) })
                    }
                }
            }
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "${if (c.currentIndex >= 0) c.currentIndex + 1 else 0} / ${c.queue.size}",
                    fontWeight = FontWeight.Bold, textAlign = TextAlign.Center,
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Rounded.Timer, null, Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(
                        " " + formatTime(c.queue.sumOf { it.durationMs }),
                        style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            Box(Modifier.size(48.dp).bounceClick { if (c.queue.isNotEmpty()) saveDialog = true }, contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.Save, null)
            }
            Box {
                Box(Modifier.size(48.dp).bounceClick { moreMenu = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.MoreHoriz, null) }
                DropdownMenu(moreMenu, { moreMenu = false }) {
                    DropdownMenuItem(text = { Text("Export as .csv") }, onClick = {
                        moreMenu = false
                        actions.saveText("$qName.csv", "text/csv", queueCsv(c.queue))
                    })
                    DropdownMenuItem(text = { Text("Export as .m3u8") }, onClick = {
                        moreMenu = false
                        actions.saveText("$qName.m3u8", "audio/x-mpegurl", queueM3u8(c.queue))
                    })
                    DropdownMenuItem(text = { Text("Select all") }, onClick = { moreMenu = false; sel.clear(); sel.addAll(c.queue.indices) })
                    DropdownMenuItem(text = { Text("Clear this queue") }, onClick = { moreMenu = false; c.clearQueue() })
                }
            }
        }

        // ---- list ----
        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (c.queue.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("This queue is empty.\nPlay a song or use “Add to queue”.", color = MaterialTheme.colorScheme.onSurfaceVariant, textAlign = TextAlign.Center)
                }
            } else {
                LazyColumn(state = state, contentPadding = PaddingValues(bottom = 24.dp)) {
                    itemsIndexed(shown, key = { _, idx -> keys.getOrElse(idx) { "x$idx" } }) { _, idx ->
                        val t = c.queue.getOrNull(idx) ?: return@itemsIndexed
                        val key = keys.getOrElse(idx) { "x$idx" }
                        val dragging = dragKey == key
                        val idxState = rememberUpdatedState(idx)
                        Box(
                            Modifier
                                .then(if (dragging) Modifier else Modifier.animateItem())
                                .zIndex(if (dragging) 1f else 0f)
                                .graphicsLayer { translationY = if (dragging) dragDy else 0f }
                                .background(MaterialTheme.colorScheme.background),
                        ) {
                            TrackRow(
                                t, c,
                                selected = idx in sel,
                                onLongClick = { toggle(idx) },
                                leading = {
                                    if (query.isBlank()) Box(
                                        Modifier.size(32.dp).pointerInput(key) {
                                            detectDragGestures(
                                                onDragStart = { dragKey = key; dragDy = 0f },
                                                onDragEnd = { dragKey = null; dragDy = 0f },
                                                onDragCancel = { dragKey = null; dragDy = 0f },
                                            ) { change, amount ->
                                                change.consume()
                                                dragDy += amount.y
                                                val infos = state.layoutInfo.visibleItemsInfo
                                                val cur = infos.firstOrNull { it.key == dragKey } ?: return@detectDragGestures
                                                val center = cur.offset + cur.size / 2f + dragDy
                                                val target = infos.firstOrNull { it.key != dragKey && center >= it.offset && center <= it.offset + it.size }
                                                if (target != null) {
                                                    val newOffset = if (target.index > cur.index) target.offset + target.size - cur.size else target.offset
                                                    c.move(cur.index, target.index)
                                                    dragDy -= (newOffset - cur.offset).toFloat()
                                                }
                                            }
                                        },
                                        contentAlignment = Alignment.Center,
                                    ) {
                                        Icon(Icons.Rounded.DragHandle, null, Modifier.size(22.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                },
                                extraMenu = buildList {
                                    add("Remove from queue" to { c.removeAt(idxState.value) })
                                    add("Move to top" to { c.move(idxState.value, 0) })
                                    add("Move to end" to { c.move(idxState.value, c.queue.lastIndex) })
                                },
                            ) { if (sel.isNotEmpty()) toggle(idx) else c.jumpTo(idx) }
                        }
                    }
                }
            }
        }

        if (sel.isNotEmpty()) {
            SelectionBar(
                c, sel.sorted().mapNotNull { c.queue.getOrNull(it) }, inQueue = true,
                onRemove = { c.removeMany(sel.toList()); sel.clear() },
                onSelectAll = { sel.clear(); sel.addAll(c.queue.indices) },
                onInvert = { val all = c.queue.indices.filter { it !in sel }; sel.clear(); sel.addAll(all) },
                onCancel = { sel.clear() },
            )
        }
        OutlinedTextField(
            query, { query = it }, singleLine = true, placeholder = { Text("Search in this queue…") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) }, shape = RoundedCornerShape(28.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
        )
    }

    if (saveDialog) NameDialog("Save queue as playlist", qName, "Save", { saveDialog = false }) {
        c.store.createPlaylist(it, c.queue.map { t -> t.id }); saveDialog = false
    }
    if (newDialog) NameDialog("New queue", "Queue ${d.queues.size + 1}", "Create", { newDialog = false }) { c.newQueue(it); newDialog = false }
    if (renameDialog) NameDialog("Rename queue", qName, "Rename", { renameDialog = false }) { c.renameQueue(c.activeQueue, it); renameDialog = false }
    if (deleteDialog) AlertDialog(
        onDismissRequest = { deleteDialog = false },
        title = { Text(if (d.queues.size > 1) "Delete this queue?" else "Clear this queue?") },
        text = { Text("“$qName” with ${c.queue.size} songs.") },
        confirmButton = { TextButton({ c.deleteQueue(c.activeQueue); deleteDialog = false }) { Text(if (d.queues.size > 1) "Delete" else "Clear") } },
        dismissButton = { TextButton({ deleteDialog = false }) { Text("Cancel") } },
    )
}
