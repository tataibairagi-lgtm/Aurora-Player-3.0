package com.aurora.player.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Delete
import androidx.compose.material.icons.rounded.PlaylistAdd
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.size
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.aurora.player.data.formatTime
import com.aurora.player.player.PlayerController

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QueueScreen(c: PlayerController, back: () -> Unit) {
    val state = rememberLazyListState()
    var saveDialog by remember { mutableStateOf(false) }
    val names = c.store.data.queues.map { it.name }

    LaunchedEffect(c.activeQueue) {
        if (c.currentIndex > 0) state.scrollToItem(c.currentIndex)
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.padding(horizontal = 4.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).bounceClick(back), contentAlignment = Alignment.Center) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, null) }
            Text("Queue", Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Box(Modifier.size(44.dp).bounceClick { if (c.queue.isNotEmpty()) saveDialog = true }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.PlaylistAdd, null) }
            Box(Modifier.size(44.dp).bounceClick { c.clearQueue() }, contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Delete, null) }
        }
        TabRow(selectedTabIndex = c.activeQueue, containerColor = Color.Transparent) {
            names.forEachIndexed { i, n ->
                Tab(selected = c.activeQueue == i, onClick = { c.switchQueue(i) }, text = { Text(n) })
            }
        }
        if (c.queue.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("This queue is empty.\nPlay a song or use “Add to queue”.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            Text(
                "${c.queue.size} songs · swipe a row to remove · ⋮ to reorder",
                Modifier.padding(16.dp, 10.dp), style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            LazyColumn(state = state, contentPadding = PaddingValues(bottom = 140.dp)) {
                itemsIndexed(c.queue, key = { i, t -> "${t.id}#$i" }) { i, t ->
                    val dismiss = rememberSwipeToDismissBoxState(
                        confirmValueChange = { v ->
                            if (v != SwipeToDismissBoxValue.Settled) { c.removeAt(i); true } else false
                        },
                    )
                    SwipeToDismissBox(
                        dismiss,
                        modifier = Modifier.animateItem(),
                        backgroundContent = {
                            Box(
                                Modifier.fillMaxSize().background(MaterialTheme.colorScheme.errorContainer).padding(horizontal = 24.dp),
                                contentAlignment = Alignment.CenterEnd,
                            ) { Icon(Icons.Rounded.Delete, null, tint = MaterialTheme.colorScheme.onErrorContainer) }
                        },
                    ) {
                        Box(Modifier.background(MaterialTheme.colorScheme.background)) {
                            TrackRow(
                                t, c,
                                extraMenu = buildList {
                                    if (i > 0) add("Move up" to { c.move(i, i - 1) })
                                    if (i < c.queue.lastIndex) add("Move down" to { c.move(i, i + 1) })
                                    if (i > 0) add("Move to top" to { c.move(i, 0) })
                                },
                            ) { c.jumpTo(i) }
                        }
                    }
                }
            }
        }
    }
    if (saveDialog) NameDialog("Save queue as playlist", "Queue", "Save", { saveDialog = false }) {
        c.store.createPlaylist(it, c.queue.map { t -> t.id }); saveDialog = false
    }
}
