package com.aurora.player.ui

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val AuroraDark = darkColorScheme(
    primary = Color(0xFFB4A8FF),
    onPrimary = Color(0xFF1E1550),
    secondary = Color(0xFF7FE3D0),
    background = Color(0xFF0F0D1A),
    surface = Color(0xFF151222),
    surfaceVariant = Color(0xFF241F38),
    onSurface = Color(0xFFEAE6FF),
    onSurfaceVariant = Color(0xFFB9B3D6),
)

private val AuroraLight = lightColorScheme(
    primary = Color(0xFF5B49D6),
    secondary = Color(0xFF00796B),
    background = Color(0xFFFBF9FF),
    surface = Color(0xFFFFFFFF),
    surfaceVariant = Color(0xFFEAE6F7),
)

@Composable
fun AuroraTheme(mode: Int, content: @Composable () -> Unit) {
    val dark = when (mode) {
        1 -> false
        2 -> true
        else -> isSystemInDarkTheme()
    }
    val ctx = LocalContext.current
    val scheme = when {
        Build.VERSION.SDK_INT >= 31 -> if (dark) dynamicDarkColorScheme(ctx) else dynamicLightColorScheme(ctx)
        dark -> AuroraDark
        else -> AuroraLight
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
